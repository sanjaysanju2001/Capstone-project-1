## Task 1 - RFM table (snapshot 2025-10-01)
customers = 1175 (ref 1,175)
recency  median=19 (19)  min=0 (0)  max=180 (180)
frequency mean=9.46 (9.46)  max=33 (33)
monetary mean=2,552.06 (2,552.06)  max=14,766.55 (14,766.55)

## Task 2 - K-means sweep (scaled RFM, n_init=10, random_state=42)
|     K |   inertia |   silhouette |   ref_inertia |   ref_silhouette |   inertia_drop_vs_prev_K |
|------:|----------:|-------------:|--------------:|-----------------:|-------------------------:|
| 2.000 |  1820.800 |        0.465 |      1820.800 |            0.465 |                  nan     |
| 3.000 |  1268.200 |        0.445 |      1268.200 |            0.445 |                 -552.600 |
| 4.000 |   743.100 |        0.526 |       743.100 |            0.526 |                 -525.100 |
| 5.000 |   617.400 |        0.480 |       617.400 |            0.481 |                 -125.700 |
| 6.000 |   503.200 |        0.482 |       503.200 |            0.482 |                 -114.200 |
| 7.000 |   408.500 |        0.416 |       408.500 |            0.416 |                  -94.700 |
| 8.000 |   366.500 |        0.412 |       366.500 |            0.412 |                  -42.000 |

Chosen K = 4

## Task 3a - segment profile (cluster numbers are arbitrary labels with no ordering)
|   segment_id |   size |   mean_recency |   mean_frequency |   mean_monetary |
|-------------:|-------:|---------------:|-----------------:|----------------:|
|            0 | 436.00 |          28.86 |             3.77 |        1,057.62 |
|            1 | 138.00 |          24.12 |             6.77 |        7,129.70 |
|            2 | 419.00 |           8.77 |            19.40 |        3,410.02 |
|            3 | 182.00 |         109.04 |             2.20 |          685.99 |

## Task 3b - names and recommended actions
|   segment_id | segment_name                |   size |   mean_recency |   mean_frequency |   mean_monetary | is_premium   | recommended_action                                                                                          |
|-------------:|:----------------------------|-------:|---------------:|-----------------:|----------------:|:-------------|:------------------------------------------------------------------------------------------------------------|
|            0 | Occasional Low-Value Buyers |    436 |          28.86 |             3.77 |        1,057.62 | False        | Grow frequency: introductory bundles and category cross-sell nudges.                                        |
|            1 | Premium Big Spenders        |    138 |          24.12 |             6.77 |        7,129.70 | True         | VIP programme: early access to Electronics launches, a dedicated support line and personal win-back offers. |
|            2 | Loyal Everyday Shoppers     |    419 |           8.77 |            19.40 |        3,410.02 | False        | Protect the habit: subscriptions, free-delivery thresholds and small basket-building rewards.               |
|            3 | Dormant / Lapsing           |    182 |         109.04 |             2.20 |          685.99 | False        | Win-back: time-limited coupon and a 'we miss you' message before they are lost.                             |

## Task 3c - PCA explained_variance_ratio_ = 0.634, 0.218; total = 0.852 (ref 0.634 / 0.218 / 0.852)
sizes sorted = [138, 182, 419, 436] (ref about 138/182/419/436)
premium: n=138 mean_monetary=7,130 (~7,130) mean_frequency=6.8 (~6.8)
loyal  : n=419 mean_frequency=19.4 (~19.4) mean_recency=8.8 (~8.8)
