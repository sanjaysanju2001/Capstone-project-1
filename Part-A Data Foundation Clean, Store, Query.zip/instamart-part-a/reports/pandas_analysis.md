## (a) pivot_table(margins=True) of revenue by city x category (INR)
| city      |      Dairy |   Electronics |    Grocery |   Personal Care |     Snacks |          All |
|:----------|-----------:|--------------:|-----------:|----------------:|-----------:|-------------:|
| Bengaluru |  87,075.05 |    233,909.45 | 110,915.65 |       20,193.85 |  71,549.40 |   523,643.40 |
| Chennai   |  78,301.80 |    195,508.80 |  93,817.45 |       27,675.40 |  68,325.70 |   463,629.15 |
| Delhi     | 117,271.70 |    158,549.10 | 112,658.05 |       23,471.50 |  90,879.45 |   502,829.80 |
| Hyderabad |  83,731.00 |    228,913.10 | 109,475.40 |       24,800.05 |  81,670.35 |   528,589.90 |
| Mumbai    |  75,209.85 |    214,738.40 |  78,970.15 |       38,018.00 |  72,122.10 |   479,058.50 |
| Pune      |  90,349.55 |    187,629.25 | 108,456.60 |       34,275.15 |  80,207.50 |   500,918.05 |
| All       | 531,938.95 |  1,219,248.10 | 614,293.30 |      168,433.95 | 464,754.50 | 2,998,668.80 |

pivot grand total = INR 2,998,668.80; SQL total = INR 2,998,668.80; equal: True

Per-city sum / mean / count of completed order_amount:
| city      |      total |   mean |    count |
|:----------|-----------:|-------:|---------:|
| Bengaluru | 523,643.40 | 276.47 | 1,894.00 |
| Chennai   | 463,629.15 | 272.72 | 1,700.00 |
| Delhi     | 502,829.80 | 243.62 | 2,064.00 |
| Hyderabad | 528,589.90 | 284.95 | 1,855.00 |
| Mumbai    | 479,058.50 | 297.00 | 1,613.00 |
| Pune      | 500,918.05 | 252.48 | 1,984.00 |

## (b) completed order_amount - statistics
|                            |   value |
|:---------------------------|--------:|
| mean                       |  269.91 |
| median                     |  135.00 |
| skewness                   |    4.61 |
| Q1                         |   64.80 |
| Q3                         |  297.00 |
| IQR                        |  232.20 |
| lower fence                | -283.50 |
| upper fence                |  645.30 |
| outliers below lower fence |    0.00 |
| outliers above upper fence |  897.00 |

Correlation matrix (completed orders):
|                  |   order_amount |   discount_pct |   quantity |   delivery_minutes |
|:-----------------|---------------:|---------------:|-----------:|-------------------:|
| order_amount     |          1.000 |         -0.095 |      0.087 |             -0.003 |
| discount_pct     |         -0.095 |          1.000 |     -0.000 |             -0.010 |
| quantity         |          0.087 |         -0.000 |      1.000 |             -0.013 |
| delivery_minutes |         -0.003 |         -0.010 |     -0.013 |              1.000 |

Largest |correlation|: order_amount vs discount_pct = -0.095
order_amount vs quantity = 0.087
