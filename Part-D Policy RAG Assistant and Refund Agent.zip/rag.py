"""rag.py -- Part D tasks 1-4: chunking, TF-IDF retrieval, augmented answering, evaluation."""
import csv, os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import mock_llm

BASE = os.path.dirname(os.path.abspath(__file__))
POLICY_DIR = os.path.join(BASE, "data", "policies")
EVAL_CSV = os.path.join(BASE, "data", "raw", "policy_eval.csv")


# ---------------- Task 1: chunking ----------------
def chunk_words(words, size=40, overlap=10):
    """Word windows: first covers 0..size-1, next starts size-overlap later.
    Stop after the first chunk whose end reaches or passes the last word."""
    step = size - overlap
    chunks, start = [], 0
    while True:
        chunks.append(" ".join(words[start:start + size]))
        if start + size >= len(words):
            break
        start += step
    return chunks


def load_chunks(size=40, overlap=10, policy_dir=POLICY_DIR):
    out = []
    for fn in sorted(os.listdir(policy_dir)):
        if not fn.endswith(".txt"):
            continue
        with open(os.path.join(policy_dir, fn), encoding="utf-8") as f:
            words = f.read().split()
        for c in chunk_words(words, size, overlap):
            out.append({"source": fn, "text": c})
    return out


# ---------------- Task 2: vectorise and retrieve ----------------
class Index:
    def __init__(self, size=40, overlap=10):
        self.chunks = load_chunks(size, overlap)
        self.vectorizer = TfidfVectorizer()
        self.matrix = self.vectorizer.fit_transform([c["text"] for c in self.chunks])

    def retrieve(self, query, k=3):
        q = self.vectorizer.transform([query])          # same fitted vectorizer
        sims = cosine_similarity(q, self.matrix)[0]
        order = sorted(range(len(sims)), key=lambda i: (-sims[i], i))[:k]
        return [{"source": self.chunks[i]["source"], "score": float(sims[i]),
                 "text": self.chunks[i]["text"]} for i in order]


DEFAULT_INDEX = Index(40, 10)


def retrieve(query, k=3, index=None):
    return (index or DEFAULT_INDEX).retrieve(query, k)


# ---------------- Task 3: augment and answer ----------------
SYSTEM_PROMPT = ("You are the POLICY ASSISTANT for Instamart support. Answer the question using only the "
                 "supplied CONTEXT. If the context does not contain the answer, say that you could not "
                 "find the information.")


def answer(question, index=None):
    hits = retrieve(question, 3, index)
    context = "\n".join(f"[{h['source']}]\n{h['text']}" for h in hits)
    user = f"CONTEXT:\n{context}\nQUESTION:\n{question}"
    reply = mock_llm.chat([{"role": "system", "content": SYSTEM_PROMPT},
                           {"role": "user", "content": user}])
    return {"text": reply["content"], "sources": [h["source"] for h in hits]}


# ---------------- Task 4: evaluation ----------------
def evaluate(size=40, overlap=10):
    idx = Index(size, overlap)
    ans_n = doc_ok = fact_ok = unans_n = fallback_ok = 0
    failures = []
    with open(EVAL_CSV, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            res = answer(r["question"], idx)
            if r["expected_doc"] == "NONE":
                unans_n += 1
                if res["text"].startswith("I could not find"):
                    fallback_ok += 1
                else:
                    failures.append((r["question"], "should have fallen back", res["text"]))
            else:
                ans_n += 1
                d = r["expected_doc"] in res["sources"]
                fa = r["expected_fact"] in res["text"]
                doc_ok += d
                fact_ok += fa
                if not (d and fa):
                    failures.append((r["question"], f"doc_in_top3={d} fact_in_answer={fa}", res["text"]))
    return {"chunks": len(idx.chunks), "answerable": ans_n, "doc_hits": doc_ok, "fact_hits": fact_ok,
            "unanswerable": unans_n, "fallbacks": fallback_ok, "failures": failures}


if __name__ == "__main__":
    from collections import Counter
    ch = load_chunks()
    print(len(ch), Counter(c["source"] for c in ch))
    print([h["source"] for h in retrieve("refund policy late delivery")])
