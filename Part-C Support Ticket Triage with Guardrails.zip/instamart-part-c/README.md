# Instamart Customer Intelligence - Part C: Support Ticket Triage with Guardrails

All monetary amounts are in **INR**. The data is synthetic and fictional.

> **Important - the mock model.** The task is built around a supplied `mock_llm.py`, which was **not available** when this
> repository was assembled. `src/mock_llm.py` is therefore a **stand-in** written from the task description (same behaviour:
> 19 transient failures, chatty/unusable answers, zero-shot confusions). The pipeline code is real and talks to the model
> through one adapter block at the top of `src/09_triage.py` (five names: `est_tokens`, `TransientLLMError`, `reset`, `chat`,
> `usage.total_tokens`). **Replace `src/mock_llm.py` with your supplied file** (adjust the adapter block if its names differ)
> and re-run; the numbers below were produced with the stand-in, so only a run with your own mock proves the reference values for your submission.

## Reproduce

1. Clone the repository and enter it (work is on branch `main`).
2. Create and activate an isolated virtual environment: `python -m venv .venv`, then `source .venv/bin/activate` (Windows: `.venv\Scripts\activate`).
3. Install the libraries: `pip install -r requirements.txt` (pandas, tabulate; regenerate it with `pip freeze` in your venv).
4. Put your supplied `mock_llm.py` in `src/` (overwriting the stand-in).
5. Run the pipeline: `python src/09_triage.py` (writes `outputs/triage_results.csv`, `outputs/triage_budget_demo.csv`, `outputs/prompt_comparison.csv`, `reports/part_c_report.md`, `reports/run_details_*.csv`).
6. Check the outputs: `python src/10_validate_c.py` - prints `PART C ALL CHECKS PASSED`.

Steps 5-6 in one go: `./run_part_c.sh`. Inputs: `data/raw/tickets.csv` (read with `keep_default_na=False` so empty texts stay empty strings) and `outputs/customer_segments.csv` from Part B.

## Pipeline (what happens to every ticket, in file order)

1. **Input guardrails** - empty/whitespace text -> `skipped_empty`; `est_tokens(text) > MAX_INPUT_TOKENS = 400` -> `flagged_long`. Neither is ever sent to the model.
2. **Redaction** - email `[\w.+-]+@[\w-]+\.[\w.]+` -> `[EMAIL]`, then phone `\b[6-9]\d{9}\b` -> `[PHONE]`, then order id `ORD-\d{6}` -> `[ORDER_ID]`. The user message sent is exactly the redacted ticket text.
3. **Model call with retries** - up to 3 retries per ticket; wait before retry n = `0.05 * 2**n * random.uniform(0.9, 1.15)` seconds; one log line per retry. `mock_llm.reset()` is called immediately before every full run.
4. **Validation** - JSON with an allowed category -> `classified_json`; if the reply is not JSON, `re.findall(r"[a-z]+", text.lower())` and exactly one allowed category word -> `classified_keyword`; anything else (including valid JSON with a category outside the list) -> `flagged_invalid_output`. Never guessed.
5. **Token budget** - before each call, if the running total of `usage.total_tokens` is already >= the budget, no call is made and the status is `budget_exhausted`.
6. **Routing** - using `outputs/customer_segments.csv` from Part B (see below).

## C1. Input guardrails

| Item | Found | Reference |
|---|---:|---:|
| tickets | 164 | 164 |
| empty tickets (`skipped_empty`) | 4 | 4 |
| long tickets (`flagged_long`) | 4 | 4 |
| estimated tokens of a long ticket | 734 | 734 |

The code asserts that no empty or long ticket produced a model call (they carry 0 tokens and no reply), and that the number of calls made equals the 156 eligible tickets.

## C2. Redaction (all 164 tickets)

| Type | Substitutions | Reference |
|---|---:|---:|
| email -> `[EMAIL]` | 55 | 55 |
| phone -> `[PHONE]` | 91 | 91 |
| order id -> `[ORDER_ID]` | 132 | 132 |
| **total** | **278** | **278** |

Re-applying the three patterns to the redacted texts finds **0** matches. Inside the pipeline an assertion checks, for every ticket sent, that the system prompt and the user message contain no email, phone or order id, and that the user message equals the redacted ticket text exactly.

## C3. The two prompts

* **Zero-shot** (33 estimated tokens): contains `CLASSIFY`, lists billing / delivery / technical / fraud, requires a JSON-only reply `{"category": "...", "reason": "..."}`, and has no `EXAMPLES:` line.
* **Few-shot** (149 estimated tokens): the same instructions plus a line `EXAMPLES:` followed by four labelled examples (billing, delivery, technical and a **fraud** example). Full text in `reports/part_c_report.md`.

## C4. Resilient calls

Each full run produced **19** transient failures, all recovered by a retry; **0** permanent errors. All 19 retries were retry number 0, with waits between 0.0450 and 0.0575 s (asserted for every retry). One log line per retry is printed and stored in `reports/part_c_report.md`, e.g. `RETRY ticket=T0124 retry=0 wait=0.0530s`.

## C5. Validation of every answer (one full run over the 156 eligible tickets)

| Status | Found | Reference |
|---|---:|---:|
| classified_json | 135 | 135 |
| classified_keyword | 12 | 12 |
| flagged_invalid_output | 9 | 9 |

The 12 keyword answers have the form "The customer appears to have a billing-related problem."; `re.findall(r"[a-z]+", ...)` separates `billing-related` into `billing` and `related`, which a plain whitespace split would not. The 9 invalid answers were: unusable text without a category word (3), valid JSON with the disallowed category "refund" (2), an empty category (2), and a reply naming two categories (2); all go to human review.

## C6. Zero-shot versus few-shot (no token budget)

| Run | Classified | Correct | Accuracy | Total tokens | Tokens per classified ticket |
|---|---:|---:|---:|---:|---:|
| Zero-shot | 147 | 126 | 85.7% | 10,134 | 68.9 |
| Few-shot | 147 | 147 | 100.0% | 28,230 | 192.0 |

Zero-shot confusion table over the 147 classified tickets (rows = true, columns = predicted):

| true \ predicted | billing | delivery | fraud | technical |
|---|---:|---:|---:|---:|
| billing | 38 | 0 | 0 | 0 |
| delivery | 0 | 35 | 0 | 0 |
| fraud | 11 | 0 | 24 | 0 |
| technical | 10 | 0 | 0 | 29 |

All 21 zero-shot errors are fraud tickets predicted billing (11) or technical tickets predicted billing (10).

**When are the extra few-shot tokens worth paying for?** The few-shot prompt costs 192.0 tokens per classified ticket against 68.9 (2.8 times as much, 18,096 more tokens over the run) and in exchange fixes all 21 errors, which is about 860 extra tokens for each additional correct ticket. That is clearly worth it when a wrong label is expensive: 11 of the zero-shot errors were fraud tickets sent towards billing instead of the security team, which the escalation policy wants to reach within 2 hours, so the extra tokens buy a faster response to the most sensitive cases. It is not worth it when ticket volume is very high and mistakes are cheap and easy to correct, or if the examples could be shortened (the prompt is re-sent with every ticket, so its length is multiplied by the volume).

## C7. Budget, routing and output

**(a) Budget demo** (`outputs/triage_budget_demo.csv`): zero-shot prompt, `TOKEN_BUDGET = 6000`. The run stopped making calls once the running total reached 6,000: **63 tickets ended `budget_exhausted`** (6,043 tokens spent; 81 classified_json, 8 classified_keyword, 4 flagged_invalid_output, 4 skipped_empty, 4 flagged_long). The count depends on the prompt length and on the mock, only "at least one exhausted and a reported count" matters.

**(b) Final output** (`outputs/triage_results.csv`): few-shot run with `TOKEN_BUDGET = 100000` (no ticket was exhausted), 164 rows, columns `ticket_id, customer_id, status, category, segment_name, priority, route, tokens_used`. Routing rules, applied in this order:

1. status `skipped_empty`, `flagged_long`, `flagged_invalid_output` or `budget_exhausted` -> `human_review`, `NORMAL`;
2. otherwise category `fraud` -> `security_team`, `HIGH`;
3. otherwise customer's `is_premium` true -> `premium_desk`, `HIGH` (a customer without a row in `customer_segments.csv` counts as not premium; here every ticket's customer had a row);
4. otherwise -> `support_queue`, `NORMAL`.

| Route | Priority | Tickets |
|---|---|---:|
| human_review | NORMAL | 17 |
| security_team | HIGH | 35 |
| premium_desk | HIGH | 11 |
| support_queue | NORMAL | 101 |

## What was rule-validated and what went to humans

* **Rule-validated and routed automatically (147 tickets):** 135 answers passed the JSON check (allowed category) and 12 passed the single-keyword check. They were routed to `security_team` (35), `premium_desk` (11) or `support_queue` (101). "Validated" means the answer has a well-formed, allowed category; it does **not** prove the category is correct (in the zero-shot run the 21 wrong labels all passed validation, which is why the few-shot prompt is used for the final output).
* **Sent to human review (17 tickets):** 4 empty tickets (never sent to the model), 4 too-long tickets (never sent), and 9 tickets whose answer was unusable (`flagged_invalid_output`). In the budget demo, tickets stopped by the budget also go to human review.

## Limitations and Next Steps

* The model here is a stand-in for the supplied `mock_llm.py` (see the note at the top); numbers must be regenerated with the real mock before submission, and token counts use the mock's `est_tokens`, not a real tokenizer.
* Redaction only covers the three required patterns (emails, 10-digit mobile numbers starting 6-9, 6-digit order ids); names, addresses or card numbers written in free text would not be caught.
* The keyword fallback accepts a reply that mentions exactly one category even if it is hedged; a ticket that says "not fraud" would pass. Output validation checks format, not truth.
* The `is_premium` flag comes from Part B's whole-window RFM, a post-hoc label that includes September; it is fine for routing demonstrations but would need a time-correct definition in production.
* Next steps: log the model's `reason` for audit, add a confidence threshold, measure real cost per ticket, and review a sample of automatically routed tickets by hand.
