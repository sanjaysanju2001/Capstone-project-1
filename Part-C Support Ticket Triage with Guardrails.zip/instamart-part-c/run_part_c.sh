#!/usr/bin/env bash
# Runs all of Part C from the repo root.
set -euo pipefail
python src/09_triage.py > /dev/null
python src/10_validate_c.py
