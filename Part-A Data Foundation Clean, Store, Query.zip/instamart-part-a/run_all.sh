#!/usr/bin/env bash
# Regenerates raw data, audits, cleans, stores, validates and runs all analysis. Run from the repo root.
set -euo pipefail
python generate_data.py
python src/01_audit.py       > /dev/null
python src/02_clean.py       > /dev/null
python src/03_validate.py
python src/04_run_sql.py     | tail -1
python src/05_pandas_analysis.py | tail -1
