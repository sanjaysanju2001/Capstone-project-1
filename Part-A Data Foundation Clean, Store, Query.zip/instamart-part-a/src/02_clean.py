"""Part A / Tasks 3-5 - clean customers and orders, write data/clean/*.csv and data/instamart.db.
Every rule logs how many rows/values it changed; the log is saved to reports/cleaning_log.json."""
import json, os, sqlite3
import pandas as pd

RAW, CLEAN, DB = "data/raw/", "data/clean/", "data/instamart.db"
os.makedirs(CLEAN, exist_ok=True)
NA = dict(keep_default_na=False, na_values=[""])      # keep literal "N/A"/"error" visible as strings
log = {}

products = pd.read_csv(RAW + "products.csv", **NA)

# =====================================================================  CUSTOMERS
cust = pd.read_csv(RAW + "customers.csv", **NA)

# (a) city: strip + title case
before = cust["city"].nunique()
new_city = cust["city"].str.strip().str.title()
log["cust_city_values_changed"] = int((new_city != cust["city"]).sum())
cust["city"] = new_city
log["cust_city_spellings_before_after"] = [int(before), int(cust["city"].nunique())]

# (b) gender -> male / female / unknown
g = cust["gender"].fillna("").str.strip().str.lower()
cust["gender"] = g.map(lambda x: "male" if x in ("m", "male") else "female" if x in ("f", "female") else "unknown")
log["cust_gender_counts"] = cust["gender"].value_counts().to_dict()

# (c) ages outside 10-100 -> missing, then fill with city median via groupby + transform
cust["age"] = pd.to_numeric(cust["age"], errors="coerce")
bad_age = (cust["age"] < 10) | (cust["age"] > 100)
log["cust_ages_outside_10_100_set_missing"] = int(bad_age.sum())
cust.loc[bad_age, "age"] = pd.NA
cust["age"] = cust["age"].astype("float64")
log["cust_missing_age_before_fill"] = int(cust["age"].isna().sum())
cust["age"] = cust["age"].fillna(cust.groupby("city")["age"].transform("median"))
log["cust_missing_age_after_fill"] = int(cust["age"].isna().sum())
log["cust_non_integer_ages_after_fill"] = int((cust["age"] % 1 != 0).sum())

# (d) signup_date -> datetime
cust["signup_date"] = pd.to_datetime(cust["signup_date"], format="%Y-%m-%d")

# =====================================================================  ORDERS
o = pd.read_csv(RAW + "orders.csv", dtype=str, **NA)
log["orders_raw_rows"] = len(o)

# 1. order_ts -> datetime
o["order_ts"] = pd.to_datetime(o["order_ts"], format="%Y-%m-%d %H:%M:%S")
o["quantity"] = o["quantity"].astype(int)
o["discount_pct"] = o["discount_pct"].astype(int)
o["delivery_minutes"] = pd.to_numeric(o["delivery_minutes"], errors="coerce")

# 2. remove exact duplicate rows (compare on raw strings incl. amount)
n = len(o); o = o.drop_duplicates().copy()
log["rule2_exact_duplicates_removed"] = n - len(o)

# 3. keep the latest order_ts per order_id (drops the earlier 'pending' records)
n = len(o)
o = o.sort_values(["order_id", "order_ts"]).drop_duplicates("order_id", keep="last").copy()
log["rule3_superseded_records_removed"] = n - len(o)

# 4. order_amount -> numeric (coerce), then fill from product price
o["order_amount"] = pd.to_numeric(o["order_amount"], errors="coerce")
o = o.merge(products[["product_id", "category", "price_inr"]], on="product_id", how="left")
miss = o["order_amount"].isna()
log["rule4_unparseable_amounts_filled"] = int(miss.sum())
calc = (o["price_inr"] * o["quantity"] * (1 - o["discount_pct"] / 100)).round(2)
o.loc[miss, "order_amount"] = calc[miss]

# 5. delivery_minutes: negatives -> missing; completed -> fill with category median (completed only)
neg = o["delivery_minutes"] < 0
log["rule5_negative_delivery_set_missing"] = int(neg.sum())
o.loc[neg, "delivery_minutes"] = pd.NA
o["delivery_minutes"] = o["delivery_minutes"].astype("float64")
completed = o["status"] == "completed"
cat_median = o["delivery_minutes"].where(completed).groupby(o["category"]).transform("median")
fill_mask = completed & o["delivery_minutes"].isna()
log["rule5_completed_delivery_filled"] = int(fill_mask.sum())
o.loc[fill_mask, "delivery_minutes"] = cat_median[fill_mask]
log["rule5_cancelled_left_missing"] = int((~completed & o["delivery_minutes"].isna()).sum())

o = o.drop(columns=["category", "price_inr"]).sort_values("order_id").reset_index(drop=True)

# ---- summary figures
log["orders_clean_rows"] = len(o)
log["orders_status_counts"] = o["status"].value_counts().to_dict()
log["orders_missing_amount"] = int(o["order_amount"].isna().sum())
log["orders_missing_delivery_completed"] = int(o.loc[o.status == "completed", "delivery_minutes"].isna().sum())
log["orders_missing_delivery_cancelled"] = int(o.loc[o.status == "cancelled", "delivery_minutes"].isna().sum())
log["completed_revenue_inr"] = round(float(o.loc[o.status == "completed", "order_amount"].sum()), 2)
log["cust_city_counts"] = cust["city"].value_counts().to_dict()

# ---- store: CSV + SQLite (order_ts / signup_date stored as text)
o_out = o.copy(); o_out["order_ts"] = o_out["order_ts"].dt.strftime("%Y-%m-%d %H:%M:%S")
c_out = cust.copy(); c_out["signup_date"] = c_out["signup_date"].dt.strftime("%Y-%m-%d")
o_out.to_csv(CLEAN + "orders.csv", index=False)
c_out.to_csv(CLEAN + "customers.csv", index=False)
products.to_csv(CLEAN + "products.csv", index=False)

if os.path.exists(DB):
    os.remove(DB)
with sqlite3.connect(DB) as con:
    c_out.to_sql("customers", con, index=False)
    products.to_sql("products", con, index=False)
    o_out.to_sql("orders", con, index=False)

os.makedirs("reports", exist_ok=True)
with open("reports/cleaning_log.json", "w") as f:
    json.dump(log, f, indent=2)
print(json.dumps(log, indent=2))
