"""Part B acceptance checks. Prints exactly PART B ALL CHECKS PASSED when everything holds."""
import joblib
import pandas as pd

seg = pd.read_csv("outputs/customer_segments.csv")
assert list(seg.columns) == ["customer_id", "recency", "frequency", "monetary", "segment_id", "segment_name", "is_premium"]
assert len(seg) == 1175 and seg.customer_id.is_unique
top_seg = seg.groupby("segment_id")["monetary"].mean().idxmax()
assert (seg.is_premium == (seg.segment_id == top_seg)).all(), "Premium must be exactly the highest-mean-monetary segment"
assert seg.segment_id.nunique() == 4 and sorted(seg.segment_id.value_counts()) == [138, 182, 419, 436]

ret = pd.read_csv("outputs/retention_list.csv")
assert list(ret.columns) == ["customer_id", "lapse_probability", "actually_lapsed"] and 1 <= len(ret) <= 10
assert ret.customer_id.isin(seg.loc[seg.is_premium, "customer_id"]).all()
assert ret.lapse_probability.is_monotonic_decreasing

feat = pd.read_csv("outputs/lapse_features.csv")
assert len(feat) == 1156 and feat["lapsed"].sum() == 443
assert not any(c.startswith("segment") or c == "is_premium" for c in feat.columns), "segment labels must not be features"
assert feat.drop(columns=["customer_id"]).isna().sum().sum() == 0

model = joblib.load("outputs/lapse_model.joblib")
X = feat.drop(columns=["customer_id", "lapsed"])
assert model.predict(X).shape[0] == 1156
print("PART B ALL CHECKS PASSED")
