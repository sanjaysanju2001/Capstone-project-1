"""agent.py -- Part D tasks 6-8: ReAct loop, safety limits, checkpoint/resume."""
import json, os, time, uuid
import mock_llm
from tools import TOOL_MAP, TOOLS_SPEC

BASE = os.path.dirname(os.path.abspath(__file__))
STATE_DIR = os.path.join(BASE, "state")
os.makedirs(STATE_DIR, exist_ok=True)

SYSTEM_PROMPT = ("You are a refund AGENT for Instamart. Decide refund requests by calling tools: look up the order, "
                 "check the policy, calculate the refund, then issue it or escalate it. Finish with one line "
                 "'STATUS: explanation' where STATUS is REFUND, ESCALATE, DENIED or NOT_FOUND.")


class SimulatedCrash(RuntimeError):
    def __init__(self, run_id):
        super().__init__(f"simulated crash in run {run_id}")
        self.run_id = run_id


def _checkpoint_path(run_id):
    return os.path.join(STATE_DIR, f"{run_id}.json")


def _save(st):
    with open(_checkpoint_path(st["run_id"]), "w", encoding="utf-8") as f:
        json.dump({k: st[k] for k in ("run_id", "scenario_id", "messages", "tokens_used", "step",
                                      "tools_executed", "steps", "llm_calls", "max_iterations",
                                      "token_limit", "time_limit_seconds")}, f, indent=1)


def _refund_amount(st):
    for s in reversed(st["steps"]):
        if s["tool"] in ("issue_refund", "escalate_to_human"):
            return s["observation"].get("refund_inr", 0.0)
    return 0.0


def _result(st, status, final):
    return {"run_id": st["run_id"], "scenario_id": st["scenario_id"], "status": status, "final_answer": final,
            "steps": st["steps"], "llm_calls": st["llm_calls"], "tokens_used": st["tokens_used"],
            "refund_inr": _refund_amount(st) if status in ("REFUND", "ESCALATE") else 0.0,
            "tools_executed": list(st["tools_executed"])}


def _fallback(st, status, reason):
    last = st["steps"][-1]["tool"] if st["steps"] else "none"
    final = (f"{status}: stopped ({reason}) after {len(st['steps'])} completed steps, {st['llm_calls']} model calls, "
             f"{st['tokens_used']} tokens; last tool: {last}. Handing the case to a human agent with this summary.")
    return _result(st, status, final)


def _loop(st, crash_after_tools=None):
    t0 = time.monotonic()
    while True:
        if time.monotonic() - t0 >= st["time_limit_seconds"]:                       # (c) wall clock
            return _fallback(st, "FALLBACK_TIMEOUT", f"time limit {st['time_limit_seconds']}s reached")
        if st["llm_calls"] >= st["max_iterations"]:                                # (a) iterations
            return _fallback(st, "FALLBACK_MAX_ITERATIONS", f"{st['max_iterations']} model calls without a final answer")
        reply = mock_llm.chat(st["messages"], tools=TOOLS_SPEC)
        st["llm_calls"] += 1
        st["tokens_used"] += reply["usage"]["total_tokens"]
        if st["tokens_used"] > st["token_limit"]:                                   # (b) tokens, tool NOT executed
            return _fallback(st, "FALLBACK_TOKEN_LIMIT", f"token limit {st['token_limit']} exceeded")
        if not reply["tool_calls"]:
            final = reply["content"]
            return _result(st, final.split(":")[0].strip(), final)
        call = reply["tool_calls"][0]
        st["messages"].append({"role": "assistant", "content": None,
                               "tool_calls": [{"id": call["id"], "name": call["name"], "arguments": call["arguments"]}]})
        fn = TOOL_MAP.get(call["name"])
        try:
            obs = fn(**call["arguments"]) if fn else {"error": f"unknown tool {call['name']}"}
        except Exception as e:                                                      # bad arguments etc.
            obs = {"error": f"{type(e).__name__}: {e}"}
        st["messages"].append({"role": "tool", "tool_call_id": call["id"], "name": call["name"],
                               "content": json.dumps(obs)})
        st["steps"].append({"tool": call["name"], "arguments": call["arguments"], "observation": obs})
        st["tools_executed"].append(call["name"])
        st["step"] += 1
        _save(st)                                                                   # checkpoint after every observation
        if crash_after_tools is not None and len(st["tools_executed"]) == crash_after_tools:
            raise SimulatedCrash(st["run_id"])


def run_agent(user_message, scenario_id, max_iterations=6, token_limit=6000, time_limit_seconds=10,
              crash_after_tools=None):
    st = {"run_id": f"{scenario_id}-{uuid.uuid4().hex[:8]}", "scenario_id": scenario_id,
          "messages": [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": user_message}],
          "tokens_used": 0, "step": 0, "tools_executed": [], "steps": [], "llm_calls": 0,
          "max_iterations": max_iterations, "token_limit": token_limit, "time_limit_seconds": time_limit_seconds}
    return _loop(st, crash_after_tools)


def resume_agent(run_id):
    with open(_checkpoint_path(run_id), encoding="utf-8") as f:
        st = json.load(f)
    return _loop(st)
