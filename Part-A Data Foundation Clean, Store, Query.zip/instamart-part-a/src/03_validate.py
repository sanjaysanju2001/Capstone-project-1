"""Part A / Task 5 - assert the reference checkpoints. Prints exactly ALL CHECKPOINTS PASSED on success."""
import sqlite3
import pandas as pd

con = sqlite3.connect("data/instamart.db")
o = pd.read_sql_query("SELECT * FROM orders", con)
c = pd.read_sql_query("SELECT * FROM customers", con)
con.close()
o_csv = pd.read_csv("data/clean/orders.csv", keep_default_na=False, na_values=[""])
comp = o[o["status"] == "completed"]

# orders
assert len(o) == 12309 and o["order_id"].is_unique, "one row per order_id (12,309)"
assert (o["status"] == "completed").sum() == 11110, "completed rows"
assert (o["status"] == "cancelled").sum() == 1199, "cancelled rows"
assert not (o["status"] == "pending").any(), "no pending rows"
assert o["order_amount"].isna().sum() == 0, "no missing order_amount"
assert comp["delivery_minutes"].isna().sum() == 0, "no missing delivery among completed"
assert o.loc[o.status == "cancelled", "delivery_minutes"].isna().sum() == 1199, "cancelled delivery stays missing"
assert round(comp["order_amount"].sum(), 2) == 2998668.80, "completed revenue INR 2,998,668.80"
assert (o["delivery_minutes"].dropna() >= 0).all(), "no negative delivery"
# customers
assert c["city"].nunique() == 6, "six cities"
assert c["city"].value_counts().to_dict() == {"Pune": 227, "Delhi": 210, "Bengaluru": 197,
                                             "Chennai": 191, "Hyderabad": 191, "Mumbai": 184}, "city counts"
assert c["gender"].value_counts().to_dict() == {"female": 610, "male": 560, "unknown": 30}, "gender counts"
assert c["age"].isna().sum() == 0 and c["age"].between(18, 60).all(), "ages 18-60, none missing"
# CSV and DB agree
assert len(o_csv) == len(o), "clean CSV matches DB"
print("ALL CHECKPOINTS PASSED")
