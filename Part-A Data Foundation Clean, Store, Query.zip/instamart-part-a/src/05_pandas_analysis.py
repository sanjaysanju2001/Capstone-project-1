"""Part A / Task 7 - pandas cross-check of Q2 and exploratory analysis of completed order_amount."""
import os, sqlite3
os.makedirs("reports", exist_ok=True)
import numpy as np
import pandas as pd

con = sqlite3.connect("data/instamart.db")
o = pd.read_sql_query("SELECT * FROM orders", con)
c = pd.read_sql_query("SELECT * FROM customers", con)
p = pd.read_sql_query("SELECT * FROM products", con)
sql_total = pd.read_sql_query("""SELECT ROUND(SUM(order_amount),2) AS t FROM orders WHERE status='completed'""", con).t[0]
con.close()

rep = []
def say(s=""):
    print(s); rep.append(s)

comp = o[o.status == "completed"].merge(c[["customer_id", "city"]], on="customer_id").merge(
    p[["product_id", "category"]], on="product_id")

# ---------------- (a) pivot_table cross-check of Q2 ----------------
pv = pd.pivot_table(comp, values="order_amount", index="city", columns="category", aggfunc="sum", margins=True)
say("## (a) pivot_table(margins=True) of revenue by city x category (INR)")
say(pv.round(2).to_markdown(floatfmt=",.2f"))
grand = round(pv.loc["All", "All"], 2)
say(f"\npivot grand total = INR {grand:,.2f}; SQL total = INR {sql_total:,.2f}; equal: {grand == sql_total}")
assert grand == sql_total

agg = comp.groupby("city").agg(total=("order_amount", "sum"), mean=("order_amount", "mean"),
                              count=("order_amount", "count")).round(2)
say("\nPer-city sum / mean / count of completed order_amount:")
say(agg.to_markdown(floatfmt=",.2f"))
assert agg.loc["Bengaluru"].tolist() == [523643.40, 276.47, 1894]
assert agg.loc["Mumbai"].tolist() == [479058.50, 297.00, 1613]

# ---------------- (b) distribution statistics ----------------
x = comp["order_amount"]
q1, q3 = x.quantile(.25), x.quantile(.75)
iqr = q3 - q1
lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
stats = {"mean": x.mean(), "median": x.median(), "skewness": x.skew(), "Q1": q1, "Q3": q3, "IQR": iqr,
         "lower fence": lo, "upper fence": hi,
         "outliers below lower fence": int((x < lo).sum()), "outliers above upper fence": int((x > hi).sum())}
say("\n## (b) completed order_amount - statistics")
say(pd.Series(stats).round(2).to_frame("value").to_markdown(floatfmt=",.2f"))
assert round(x.mean(), 2) == 269.91 and x.median() == 135.0 and round(x.skew(), 2) == 4.61
assert (round(q1, 2), round(q3, 2), round(hi, 2)) == (64.80, 297.00, 645.30)
assert stats["outliers above upper fence"] == 897 and stats["outliers below lower fence"] == 0

corr = comp[["order_amount", "discount_pct", "quantity", "delivery_minutes"]].corr()
say("\nCorrelation matrix (completed orders):")
say(corr.round(3).to_markdown(floatfmt=".3f"))
pairs = corr.where(np.triu(np.ones(corr.shape, bool), 1)).stack()
best = pairs.abs().idxmax()
say(f"\nLargest |correlation|: {best[0]} vs {best[1]} = {pairs[best]:.3f}")
say(f"order_amount vs quantity = {corr.loc['order_amount','quantity']:.3f}")
assert best == ("order_amount", "discount_pct")

open("reports/pandas_analysis.md", "w", encoding="utf-8").write("\n".join(rep) + "\n")
print("\nPANDAS CHECKS PASSED")
