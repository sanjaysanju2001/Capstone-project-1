#!/usr/bin/env bash
# Runs all of Part B from the repo root.
set -euo pipefail
python src/06_rfm_segments.py > /dev/null
python src/07_lapse_model.py  > /dev/null
python src/08_validate_b.py
