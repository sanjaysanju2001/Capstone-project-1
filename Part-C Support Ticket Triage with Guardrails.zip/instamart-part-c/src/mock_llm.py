"""STAND-IN for the supplied mock_llm.py  (the original file was not available when this repository was built).

>>> REPLACE THIS FILE with the mock_llm.py you were given. <<<
The pipeline (src/09_triage.py) only touches the five names below, all in ONE adapter block at the top of that file:
    mock_llm.reset()                       - start a fresh run (counters back to zero)
    mock_llm.chat(system_prompt, user_msg) - one model call -> object with .text and .usage.total_tokens
    mock_llm.TransientLLMError             - raised by some calls; the caller must retry
    mock_llm.est_tokens(text)              - ceil(words * 1.3); gives 734 for the long tickets, ~29 for the zero-shot prompt
If your supplied mock uses different names, edit only that adapter block.

Behaviour of this stand-in (deterministic, no randomness), modelled on the task description:
  * it reads ONLY the (redacted) user message and classifies it with keyword rules;
  * a system prompt that contains the line "EXAMPLES:" (few-shot) is answered correctly; a zero-shot prompt makes
    it confuse two ticket kinds with "billing" (fraud 'charged ... never made' and technical 'payment page');
  * calls number 5, 14, 23, ... (19 of them in a full run) raise TransientLLMError; the immediately following call (the retry) succeeds;
  * for the k-th answer served in a run, a fixed plan decides: normal JSON, a chatty sentence
    ("The customer appears to have a <category>-related problem."), or an unusable answer.
"""
import json, math, re

class TransientLLMError(Exception):
    pass

class _Usage:
    def __init__(self, prompt_tokens, completion_tokens):
        self.prompt_tokens, self.completion_tokens = prompt_tokens, completion_tokens
        self.total_tokens = prompt_tokens + completion_tokens

class _Response:
    def __init__(self, text, usage):
        self.text, self.usage = text, usage

def est_tokens(text):
    return max(1, math.ceil(len(text.split()) * 1.3)) if text.strip() else 0

FAIL_CALLS = {5 + 9 * i for i in range(19)}                      # 19 transient failures in a full run
CHATTY_K = {16, 18, 25, 31, 50, 73, 77, 86, 97, 100, 125, 127}   # 12 chatty answers
INVALID_K = [5, 42, 59, 60, 122, 139, 144, 155, 156]             # 9 unusable answers
BAD_ANSWERS = ['I am unable to determine the category for this ticket.',         # no allowed word
               '{"category": "refund", "reason": "customer wants money back"}',   # valid JSON, category not allowed
               'This could be billing or fraud, it is hard to say.',             # two allowed words
               '{"category": "", "reason": "unclear"}']                          # valid JSON, empty category

_calls = 0      # every call, including the ones that fail
_served = 0     # answers actually returned

def reset():
    global _calls, _served
    _calls = _served = 0

def _true_kind(msg):
    m = msg.lower()
    if re.search(r"unauthorized|hacked|fraud", m):
        return "fraud"
    if re.search(r"crash|login|otp|payment page|freez", m):
        return "technical"
    if re.search(r"rider|delivery|arrived|\blate\b", m):
        return "delivery"
    return "billing"

def chat(system_prompt, user_msg):
    global _calls, _served
    _calls += 1
    if _calls in FAIL_CALLS:
        raise TransientLLMError("simulated transient failure")
    _served += 1
    cat = _true_kind(user_msg)
    if "EXAMPLES:" not in system_prompt:                          # zero-shot confusions
        if "that i never made" in user_msg.lower() or "payment page" in user_msg.lower():
            cat = "billing"
    if _served in INVALID_K:
        text = BAD_ANSWERS[INVALID_K.index(_served) % len(BAD_ANSWERS)]
    elif _served in CHATTY_K:
        text = f"The customer appears to have a {cat}-related problem."
    else:
        text = json.dumps({"category": cat, "reason": f"wording matches a {cat} issue"})
    return _Response(text, _Usage(est_tokens(system_prompt) + est_tokens(user_msg), est_tokens(text)))
