## Q1 customers with >8000 from orders > 500
rows = 30  (reference 30)
| customer_id   |   n_orders |   total_amount |
|:--------------|-----------:|---------------:|
| C0693         |          6 |       13776.55 |
| C0082         |          5 |       12317.70 |
| C0743         |          5 |       12266.85 |
| C0525         |          6 |       12241.30 |
| C0291         |          6 |       12150.70 |

## Q2 revenue by city x category
rows = 30 (ref 30); total = INR 2,998,668.80 (ref 2,998,668.80)
largest cell: Bengaluru / Electronics = INR 233,909.45 (ref Bengaluru / Electronics 233,909.45)
| city      |     Dairy |   Electronics |   Grocery |   Personal Care |   Snacks |
|:----------|----------:|--------------:|----------:|----------------:|---------:|
| Bengaluru |  87075.05 |     233909.45 | 110915.65 |        20193.85 | 71549.40 |
| Chennai   |  78301.80 |     195508.80 |  93817.45 |        27675.40 | 68325.70 |
| Delhi     | 117271.70 |     158549.10 | 112658.05 |        23471.50 | 90879.45 |
| Hyderabad |  83731.00 |     228913.10 | 109475.40 |        24800.05 | 81670.35 |
| Mumbai    |  75209.85 |     214738.40 |  78970.15 |        38018.00 | 72122.10 |
| Pune      |  90349.55 |     187629.25 | 108456.60 |        34275.15 | 80207.50 |

## Q3 products above average price
rows = 11 (ref 11)
| product_id   | product_name        | category      |   price_inr |
|:-------------|:--------------------|:--------------|------------:|
| P038         | Bluetooth Speaker   | Electronics   |        1999 |
| P033         | Wireless Earbuds    | Electronics   |        1499 |
| P034         | Power Bank 10000mAh | Electronics   |        1299 |
| P036         | Phone Charger 20W   | Electronics   |         799 |
| P037         | Smart Bulb          | Electronics   |         599 |
| P040         | Memory Card 64GB    | Electronics   |         549 |
| P032         | Sunscreen 50g       | Personal Care |         399 |
| P030         | Body Lotion 400ml   | Personal Care |         350 |
| P039         | Phone Stand         | Electronics   |         349 |
| P014         | Ghee 500ml          | Dairy         |         340 |
| P035         | USB-C Cable 1m      | Electronics   |         299 |

## Q4 customers with no completed order
rows = 25 (ref 25)
| customer_id   | city      |
|:--------------|:----------|
| C0029         | Hyderabad |
| C0037         | Pune      |
| C0093         | Pune      |
| C0115         | Bengaluru |
| C0120         | Bengaluru |
...

## Q5 customers above the average total spend
rows = 550 (ref 550); average = INR 2,552.06 (ref 2,552.06)
| customer_id   |   total_spend |   avg_total |
|:--------------|--------------:|------------:|
| C0693         |      14766.55 |     2552.06 |
| C0291         |      13742.60 |     2552.06 |
| C0488         |      13187.50 |     2552.06 |
| C0082         |      12856.20 |     2552.06 |
| C0743         |      12730.05 |     2552.06 |

## Q6 ranking window functions
top customer per city:
| city      | customer_id   |   total_spend |
|:----------|:--------------|--------------:|
| Bengaluru | C0082         |      12856.20 |
| Chennai   | C0930         |      10151.40 |
| Delhi     | C0291         |      13742.60 |
| Hyderabad | C0743         |      12730.05 |
| Mumbai    | C0693         |      14766.55 |
| Pune      | C0426         |      10377.10 |
rows with RANK() != ROW_NUMBER(): 8 (ref 8)
| customer_id   | city      |   total_spend |   rnk |   dense_rnk |   row_num |
|:--------------|:----------|--------------:|------:|------------:|----------:|
| C0734         | Bengaluru |       2598.00 |    99 |          99 |       100 |
| C0723         | Bengaluru |        135.00 |   179 |         178 |       180 |
| C1053         | Mumbai    |        396.00 |   149 |         149 |       150 |
| C0608         | Mumbai    |        280.00 |   160 |         159 |       161 |
| C1064         | Pune      |       3236.95 |    74 |          74 |        75 |
| C0057         | Pune      |        285.00 |   189 |         188 |       190 |
| C0936         | Pune      |        285.00 |   189 |         188 |       191 |
| C0276         | Pune      |        114.00 |   209 |         206 |       210 |

## Q7 daily revenue + running total
daily rows = 183 (ref 183); last cumulative = INR 2,998,668.80 (ref 2,998,668.80)
| day        |   revenue |   cumulative_revenue |
|:-----------|----------:|---------------------:|
| 2025-04-01 |  16876.50 |             16876.50 |
| 2025-04-02 |  19854.55 |             36731.05 |
| 2025-04-03 |  28048.35 |             64779.40 |
| 2025-04-04 |  14249.60 |             79029.00 |
| 2025-04-05 |  16031.50 |             95060.50 |
...
