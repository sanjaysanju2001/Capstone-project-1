"""Part A / Task 2 - audit the three raw tables and print the specific audit figures."""
import os
import pandas as pd
os.makedirs("reports", exist_ok=True)

RAW = "data/raw/"
# keep_default_na=False + na_values=[""]: only a truly blank cell counts as missing, so the literal
# strings "N/A" and "error" stay visible as unparseable values instead of being silently turned into NaN.
NA = dict(keep_default_na=False, na_values=[""])
orders = pd.read_csv(RAW + "orders.csv", dtype=str, **NA)
customers = pd.read_csv(RAW + "customers.csv", dtype={"age": "string"}, **NA)
products = pd.read_csv(RAW + "products.csv", **NA)

# type-aware reload for the general profile (shape / dtypes / missing)
orders_t = pd.read_csv(RAW + "orders.csv", **NA)
customers_t = pd.read_csv(RAW + "customers.csv", **NA)

lines = []
def out(s=""):
    print(s); lines.append(s)

for name, df in [("orders", orders_t), ("customers", customers_t), ("products", products)]:
    out(f"## {name}.csv  shape={df.shape}")
    prof = pd.DataFrame({
        "dtype": df.dtypes.astype(str),
        "missing": df.isna().sum(),
        "missing_pct": (df.isna().mean() * 100).round(2)})
    out(prof.to_markdown()); out()

# ---- specific audit figures ----
amt_num = pd.to_numeric(orders["order_amount"], errors="coerce")
deliv = pd.to_numeric(orders["delivery_minutes"], errors="coerce")
age = pd.to_numeric(customers["age"], errors="coerce")
gender = customers["gender"].dropna()

audit = {
    "raw orders.csv rows": len(orders),
    "exact duplicate rows": int(orders.duplicated().sum()),
    "rows with status pending": int((orders["status"] == "pending").sum()),
    "distinct order_id": int(orders["order_id"].nunique()),
    "non-numeric order_amount": int((amt_num.isna() & orders["order_amount"].notna()).sum()),
    "negative delivery_minutes": int((deliv < 0).sum()),
    "blank delivery_minutes": int(orders["delivery_minutes"].isna().sum()),
    "customers: blank age": int(age.isna().sum()),
    "customers: age outside 10-100": int(((age < 10) | (age > 100)).sum()),
    "customers: distinct raw city spellings": int(customers["city"].nunique()),
    "customers: distinct non-blank raw gender spellings": int(gender.nunique()),
    "customers: blank gender": int(customers["gender"].isna().sum()),
}
reference = [13084, 119, 656, 12309, 120, 106, 2541, 61, 6, 24, 10, 30]
tbl = pd.DataFrame({"audit figure": audit.keys(), "found": audit.values(), "reference": reference})
tbl["match"] = tbl["found"] == tbl["reference"]
out("## Audit figures"); out(tbl.to_markdown(index=False))
with open("reports/audit_report.md", "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")
