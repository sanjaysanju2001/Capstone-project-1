# Instamart Customer Intelligence — Part D: Policy RAG Assistant and Refund Agent

Everything is offline: `mock_llm.py` is a deterministic stand-in for the model, and no network call or API key is used.

## How to run
```
python generate_data.py      # data/raw/*.csv and data/policies/*.txt
python run_part_d.py         # runs all Part D tasks, writes outputs/, state/ and this README
```
Files: `rag.py` (tasks 1-4), `tools.py` (task 5), `agent.py` (tasks 6-8), `mock_llm.py`, `build_db.py`.
`data/instamart.db` is the Part A database; if you already have yours with an `orders` table it is used as is,
otherwise `build_db.py` builds a stand-in from `orders.csv` (duplicates removed, bad values set to NULL).

## Part D

### 1. Chunking (40 words, overlap 10)
15 chunks in total: refund 4, delivery 3, escalation 3, payment 3, privacy 2. Matches the reference (15: refund 4, delivery 3, escalation 3, payment 3, privacy 2).

### 2. TF-IDF retrieval
`retrieve(query, k=3)` fits `TfidfVectorizer()` on the chunk texts, transforms the query with the same fitted vectorizer and ranks by `cosine_similarity`.
For "refund policy late delivery" the top three sources are ['refund_policy.txt', 'refund_policy.txt', 'refund_policy.txt'].

TF (term frequency) measures how often a word occurs within one chunk, and IDF (inverse document frequency) measures how rare the word is across all chunks, so common words count less. A limitation: TF-IDF matches exact words only, so a question such as "money back for a slow rider" would miss "refund" and "late delivery" even though the meaning is the same.

### 3. Augment and answer
`answer(question)` retrieves three chunks and sends a system message containing POLICY ASSISTANT plus a user message `CONTEXT:\n[file]\nchunk...\nQUESTION:\n<question>` to `mock_llm.chat`, returning the text and sources.

### 4. Retrieval and grounding evaluation
| Setting | Chunks | Expected doc in top 3 (of 12) | Answer contains expected_fact (of 12) | Fallback "I could not find" (of 2) |
|---|---|---|---|---|
| 40 words, overlap 10 | 15 | 12 | 12 | 2 |
| 40 words, overlap 0 | 13 | 12 | 9 | 2 |

With overlap 0, 3 answerable questions break:
- **What delivery time makes a completed order eligible for a full refund?** returned: "If a completed order is delivered in 45 minutes or less, no late-delivery refund is paid."
- **Who must approve a refund above INR 1000?** returned: "Refunds up to INR 1000 are approved automatically by the support system."
- **How soon is money returned when a payment fails but is deducted?** returned: "If a payment fails but money is deducted, the amount is returned automatically"

Why: with no overlap the 40-word cut falls in the middle of a sentence, so the part of the answer after the boundary sits in a different chunk. The model then sees a truncated sentence or only a neighbouring sentence (for example the "45 minutes or less" sentence instead of "more than 45 minutes"), and the expected fact is missing. The 10-word overlap repeats the boundary words in both chunks so the full sentence can be reassembled.

### 5. Tools
`tools.py` defines `get_order`, `search_policy`, `calculate_refund`, `issue_refund`, `escalate_to_human` in `TOOLS_SPEC` (name, one-sentence description, JSON-style parameters) and `TOOL_MAP` (name -> function). `issue_refund` and `escalate_to_human` append a JSON line with timestamp and tool name to `outputs/refund_ledger.jsonl`.

### 6. ReAct loop — seven scenarios
| Scenario | Status | Refund (INR) | Model calls | Tokens used | Matches expected |
|---|---|---|---|---|---|
| S1 | REFUND | 128.25 | 5 | 1773 | yes |
| S2 | REFUND | 135.00 | 5 | 1773 | yes |
| S3 | ESCALATE | 1999.00 | 5 | 1765 | yes |
| S4 | DENIED | 0.00 | 4 | 1216 | yes |
| S5 | DENIED | 0.00 | 3 | 706 | yes |
| S6 | NOT_FOUND | 0.00 | 2 | 233 | yes |
| S7 | FALLBACK_MAX_ITERATIONS | 0.00 | 6 | 3593 | yes |

S7 uses the default `token_limit=6000` and still completes all six model calls before `FALLBACK_MAX_ITERATIONS`.

### 7. Stopping safely
| Demo | Status | Model calls | Tokens used |
|---|---|---|---|
| S1 with token_limit=200 | FALLBACK_TOKEN_LIMIT | 2 | 294 |
| S1 with time_limit_seconds=0 | FALLBACK_TIMEOUT | 0 | 0 |

The token-limit run stops right after the model call that pushed the total over 200, without executing the tool that call requested. The timeout run stops at the top of the first iteration, before any model call. Both return the steps completed so far and a human-handoff summary in `final_answer`.

### 8. Crash and resume (S1)
A simulated crash is raised right after the second tool execution (its checkpoint `state/S1-c2a3ca6d.json` is already saved); `resume_agent("S1-c2a3ca6d")` then continues.
- Executed before the crash: get_order -> search_policy
- Executed across crash and resume, in order: **get_order -> search_policy -> calculate_refund -> issue_refund** (4 executions, none repeated)
- Final status: **REFUND 128.25**

### 9. ReAct versus plan-and-execute
My ReAct agent asks the model after every observation. Measured model calls: S1 5, S2 5, S3 5, S4 4, S5 3, S6 2; S1 used 1773 estimated tokens because every call re-sends the growing history including the policy chunks. A plan-and-execute design would call the model once for the whole step list (get_order, search_policy, calculate_refund, issue_refund) and once more to write the answer, so about 2 calls instead of 5 and far fewer tokens on the happy path S1, because the history is not re-sent each step.

The price is rigidity. For NOT_FOUND (S6, 2 calls in ReAct) a pre-written plan would still try to search policy and calculate a refund unless the executor detects the error and replans, which costs an extra model call. A cancelled order (S5, 3 calls) is worse: get_order succeeds, so nothing signals an error, and a fixed plan would carry on to calculate and even issue a refund unless every step is guarded by hand-written checks. ReAct simply reads the status and stops.

For this refund workflow I would choose ReAct, ideally with a cheap code-level guard for obvious dead ends. Money moves at the end, the correct next step depends on what the previous tool returned (status, delivery minutes, amount above INR 1000), and the extra 2-3 calls per request cost little compared with an unwarranted refund. Plan-and-execute would only win for high-volume, uniform requests where cost matters most.

## Outputs
`outputs/agent_runs.jsonl` (one line per run, including the three demo runs), `outputs/refund_ledger.jsonl` (issued and escalated actions), `state/` (checkpoints).
