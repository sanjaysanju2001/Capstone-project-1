"""Part A / Task 6 - run every query in sql/queries.sql with pd.read_sql_query and check the reference results."""
import os, re, sqlite3
os.makedirs("reports", exist_ok=True)
import pandas as pd

text = open("sql/queries.sql", encoding="utf-8").read()
blocks = re.split(r"--\s*name:\s*(Q\d)\s*\n", text)          # [preamble, 'Q1', sql, 'Q2', sql, ...]
Q = {blocks[i]: blocks[i + 1].split("\n-- Q")[0].strip() for i in range(1, len(blocks), 2)}
assert len(Q) == 7, "expected seven queries"

con = sqlite3.connect("data/instamart.db")
R = {k: pd.read_sql_query(v, con) for k, v in Q.items()}
con.close()

rep = []
def say(s=""):
    print(s); rep.append(s)

say("## Q1 customers with >8000 from orders > 500");           say(f"rows = {len(R['Q1'])}  (reference 30)")
assert len(R["Q1"]) == 30
say(R["Q1"].head(5).to_markdown(index=False, floatfmt=".2f")); say()

q2 = R["Q2"]
say("## Q2 revenue by city x category")
say(f"rows = {len(q2)} (ref 30); total = INR {q2.revenue.sum():,.2f} (ref 2,998,668.80)")
top = q2.iloc[0]; say(f"largest cell: {top.city} / {top.category} = INR {top.revenue:,.2f} (ref Bengaluru / Electronics 233,909.45)")
assert len(q2) == 30 and round(q2.revenue.sum(), 2) == 2998668.80
assert (top.city, top.category, round(top.revenue, 2)) == ("Bengaluru", "Electronics", 233909.45)
say(q2.pivot(index="city", columns="category", values="revenue").to_markdown(floatfmt=".2f")); say()

say("## Q3 products above average price"); say(f"rows = {len(R['Q3'])} (ref 11)")
assert len(R["Q3"]) == 11
say(R["Q3"].to_markdown(index=False, floatfmt=".2f")); say()

say("## Q4 customers with no completed order"); say(f"rows = {len(R['Q4'])} (ref 25)")
assert len(R["Q4"]) == 25
say(R["Q4"].head(5).to_markdown(index=False, floatfmt=".2f")); say("...")
say()

q5 = R["Q5"]
say("## Q5 customers above the average total spend")
say(f"rows = {len(q5)} (ref 550); average = INR {q5.avg_total.iloc[0]:,.2f} (ref 2,552.06)")
assert len(q5) == 550 and q5.avg_total.iloc[0] == 2552.06
say(q5.head(5).to_markdown(index=False, floatfmt=".2f")); say()

q6 = R["Q6"]
top6 = q6[q6.row_num == 1].set_index("city")
say("## Q6 ranking window functions"); say("top customer per city:")
say(top6[["customer_id", "total_spend"]].to_markdown(floatfmt=".2f"))
ref6 = {"Bengaluru": ("C0082", 12856.20), "Chennai": ("C0930", 10151.40), "Delhi": ("C0291", 13742.60),
        "Hyderabad": ("C0743", 12730.05), "Mumbai": ("C0693", 14766.55), "Pune": ("C0426", 10377.10)}
for city, (cid, amt) in ref6.items():
    assert top6.loc[city, "customer_id"] == cid and round(top6.loc[city, "total_spend"], 2) == amt, city
n_diff = int((q6.rnk != q6.row_num).sum())
say(f"rows with RANK() != ROW_NUMBER(): {n_diff} (ref 8)"); assert n_diff == 8
say(q6[q6.rnk != q6.row_num].to_markdown(index=False, floatfmt=".2f")); say()

q7 = R["Q7"]
say("## Q7 daily revenue + running total")
say(f"daily rows = {len(q7)} (ref 183); last cumulative = INR {q7.cumulative_revenue.iloc[-1]:,.2f} (ref 2,998,668.80)")
assert len(q7) == 183 and q7.cumulative_revenue.iloc[-1] == 2998668.80
say(q7.head(5).to_markdown(index=False, floatfmt=".2f")); say("...")

open("reports/sql_results.md", "w", encoding="utf-8").write("\n".join(rep) + "\n")
print("\nALL SQL REFERENCE CHECKS PASSED")
