## Task 4 - lapse problem (cutoff 2025-09-01)
cohort = 1156 (ref 1,156); lapsed = 443 (38.32%) (ref 443 / 38.32%)
train = 924 / test = 232 (ref 924 / 232); lapsed in train = 354, in test = 89

## Task 5 - preprocessing without leakage
scaler.mean_ for frequency (train only) = 8.1147; full-cohort mean of frequency = 8.0285
They differ because the scaler learned its mean from the 924 training rows only, while the full-cohort mean also includes the 232 test rows the scaler must never see.
no missing value in any feature column (raw or encoded): True; encoded width = 19 (8 numeric + 11 one-hot columns, k-1 per variable)

## Task 6 - train, tune, evaluate
(a) baseline 'always not lapsed': accuracy = 61.6% (ref 61.6%), lapsed-class F1 = 0.00 (ref 0)
(b) LogisticRegression grid C in {0.01,0.1,1,10,100}, cv=5, f1: best {'clf__C': 100}, best CV F1 = 0.6506
(c) RandomForest grid max_depth in {3,5,8} x min_samples_leaf in {5,10,20}, cv=5, f1 (45 fits): best {'clf__max_depth': 8, 'clf__min_samples_leaf': 10}, best CV F1 = 0.6811

Random-forest grid (mean CV F1):
|   param_clf__max_depth |   param_clf__min_samples_leaf |   mean_test_score |
|-----------------------:|------------------------------:|------------------:|
|                      3 |                             5 |            0.6745 |
|                      3 |                            10 |            0.6754 |
|                      3 |                            20 |            0.668  |
|                      5 |                             5 |            0.6766 |
|                      5 |                            10 |            0.6741 |
|                      5 |                            20 |            0.6743 |
|                      8 |                             5 |            0.6756 |
|                      8 |                            10 |            0.6811 |
|                      8 |                            20 |            0.6706 |

Logistic-regression grid (mean CV F1):
|      C |   mean_cv_f1 |
|-------:|-------------:|
|   0.01 |       0.5622 |
|   0.1  |       0.6462 |
|   1    |       0.6449 |
|  10    |       0.6493 |
| 100    |       0.6506 |

(d) Untouched test set (positive class = lapsed):

Logistic regression: precision = 0.644, recall = 0.652, F1 = 0.648
confusion matrix [[TN FP],[FN TP]] = [[111, 32], [31, 58]]

Random forest: precision = 0.659, recall = 0.652, F1 = 0.655
confusion matrix [[TN FP],[FN TP]] = [[113, 30], [31, 58]]

Selected model (higher cross-validated F1): Random forest; test F1 = 0.655

## Task 7 - class-balance experiment (over-sampling the TRAINING set only)
training rows before: 570 not lapsed / 354 lapsed; added 216 duplicated lapsed rows -> 570 / 570
|           |   un-balanced LR |   balanced LR |   change |
|:----------|-----------------:|--------------:|---------:|
| precision |            0.644 |         0.589 |   -0.055 |
| recall    |            0.652 |         0.854 |    0.202 |
| f1        |            0.648 |         0.697 |    0.049 |
confusion matrix balanced LR = [[90, 53], [13, 76]]

## Task 8 - interpret, persist, use
(a) top 5 random-forest feature_importances_:
|                           |   importance |
|:--------------------------|-------------:|
| num__frequency            |       0.2796 |
| num__monetary             |       0.2712 |
| num__recency              |       0.1151 |
| num__avg_delivery_minutes |       0.0613 |
| num__cancellation_rate    |       0.0523 |
logistic-regression coefficients (standardised numeric features; positive = more likely to lapse):
|                           |    coef |
|:--------------------------|--------:|
| num__recency              |  0.0396 |
| num__frequency            | -1.6982 |
| num__cancellation_rate    | -0.1236 |
| num__avg_delivery_minutes |  0.0785 |
| num__monetary             |  0.2846 |

(b) saved outputs/lapse_model.joblib (Random forest); reloaded model reproduces the original test predictions exactly: True
(c) Premium customers in the test set: 40; top-10 written to outputs/retention_list.csv; 1 of 10 truly lapsed.
| customer_id   |   lapse_probability |   actually_lapsed |
|:--------------|--------------------:|------------------:|
| C0862         |              0.4910 |                 0 |
| C1112         |              0.4841 |                 0 |
| C0060         |              0.4798 |                 0 |
| C0802         |              0.4796 |                 0 |
| C1008         |              0.4778 |                 0 |
| C1000         |              0.4624 |                 0 |
| C0525         |              0.4597 |                 1 |
| C0133         |              0.4562 |                 0 |
| C0267         |              0.4525 |                 0 |
| C0167         |              0.4522 |                 0 |
This retention list is illustrative and not a leakage-free evaluation: the Premium flag comes from whole-window RFM that includes the September window defining the lapse label.
