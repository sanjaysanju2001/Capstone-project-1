"""Part C - support-ticket triage with guardrails.
Input guardrails -> PII redaction -> prompt -> retried model call -> output validation -> token budget -> routing."""
import json, os, random, re, sys, time
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mock_llm

# ---------------------------------------------------------------- ADAPTER: the only place that touches mock_llm
est_tokens = mock_llm.est_tokens
TransientLLMError = mock_llm.TransientLLMError
def reset_model():                    mock_llm.reset()
def call_model(system_prompt, user_message):
    resp = mock_llm.chat(system_prompt, user_message)
    return resp.text, resp.usage.total_tokens
# ------------------------------------------------------------------------------------------------------------------

MAX_INPUT_TOKENS = 400
MAX_RETRIES, BASE_DELAY = 3, 0.05
ALLOWED = ["billing", "delivery", "technical", "fraud"]
PII = [("email", r"[\w.+-]+@[\w-]+\.[\w.]+", "[EMAIL]"),          # applied in exactly this order
       ("phone", r"\b[6-9]\d{9}\b", "[PHONE]"),
       ("order id", r"ORD-\d{6}", "[ORDER_ID]")]

os.makedirs("outputs", exist_ok=True); os.makedirs("reports", exist_ok=True)

# ---------------------------------------------------------------- Task 3: the two prompts
ZERO_SHOT = ('You CLASSIFY customer support tickets into exactly one category: billing, delivery, technical or fraud. '
             'Reply with JSON only, in the form {"category": "...", "reason": "..."}.')
FEW_SHOT = ('You CLASSIFY customer support tickets into exactly one category: billing, delivery, technical or fraud. '
            'Reply with JSON only, in the form {"category": "...", "reason": "..."}.\n'
            'EXAMPLES:\n'
            'Ticket: I was charged twice for order [ORDER_ID]. Please refund the extra payment. '
            '-> {"category": "billing", "reason": "double charge on an order"}\n'
            'Ticket: My order [ORDER_ID] has not arrived and the rider is not picking up calls. '
            '-> {"category": "delivery", "reason": "order not received"}\n'
            'Ticket: The app crashes every time I open the cart. '
            '-> {"category": "technical", "reason": "app fault"}\n'
            'Ticket: There is an unauthorized transaction on my card linked to order [ORDER_ID]. I did not place it. '
            '-> {"category": "fraud", "reason": "transaction the customer did not make"}')
assert "CLASSIFY" in ZERO_SHOT and "EXAMPLES:" not in ZERO_SHOT
assert "CLASSIFY" in FEW_SHOT and "EXAMPLES:" in FEW_SHOT
for p in (ZERO_SHOT, FEW_SHOT):
    assert all(c in p for c in ALLOWED) and "JSON only" in p and '{"category": "...", "reason": "..."}' in p

# ---------------------------------------------------------------- Task 2: redaction
def redact(text, counts=None):
    for name, pat, ph in PII:
        text, n = re.subn(pat, ph, text)
        if counts is not None:
            counts[name] = counts.get(name, 0) + n
    return text

def pii_left(text):
    return sum(len(re.findall(pat, text)) for _, pat, _ in PII)

# ---------------------------------------------------------------- Task 4: retries
def call_with_retry(ticket_id, system_prompt, user_message, retry_log):
    """Up to MAX_RETRIES retries; wait before retry n = BASE_DELAY * 2**n * uniform(0.9, 1.15); one log line per retry."""
    for attempt in range(MAX_RETRIES + 1):
        try:
            return call_model(system_prompt, user_message)
        except TransientLLMError:
            if attempt == MAX_RETRIES:
                raise
            n = attempt
            wait = BASE_DELAY * 2 ** n * random.uniform(0.9, 1.15)
            retry_log.append({"ticket_id": ticket_id, "retry": n, "wait": wait,
                              "line": f"RETRY ticket={ticket_id} retry={n} wait={wait:.4f}s"})
            time.sleep(wait)

# ---------------------------------------------------------------- Task 5: validation
def validate_reply(text):
    """-> (status, category).  Never guesses."""
    try:
        obj = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        words = set(re.findall(r"[a-z]+", str(text).lower()))
        hits = [w for w in ALLOWED if w in words]
        return ("classified_keyword", hits[0]) if len(hits) == 1 else ("flagged_invalid_output", "")
    if isinstance(obj, dict) and isinstance(obj.get("category"), str) and obj["category"] in ALLOWED:
        return "classified_json", obj["category"]
    return "flagged_invalid_output", ""                           # valid JSON but category outside the list

# ---------------------------------------------------------------- the pipeline
def run_pipeline(tickets, system_prompt, token_budget=None, seed=42):
    random.seed(seed)
    reset_model()                                                  # immediately before each full run
    rows, retry_log, sent, running = [], [], [], 0
    transient_before_recovery = 0
    for t in tickets.itertuples(index=False):
        row = {"ticket_id": t.ticket_id, "customer_id": t.customer_id, "true_category": t.true_category,
               "status": "", "category": "", "tokens_used": 0, "reply": ""}
        if t.text.strip() == "":                                   # (a) empty -> never sent
            row["status"] = "skipped_empty"
        elif est_tokens(t.text) > MAX_INPUT_TOKENS:                # (b) too long -> never sent
            row["status"] = "flagged_long"
        elif token_budget is not None and running >= token_budget: # budget gate: no call at all
            row["status"] = "budget_exhausted"
        else:
            user_message = redact(t.text)
            before = len(retry_log)
            try:
                reply, tokens = call_with_retry(t.ticket_id, system_prompt, user_message, retry_log)
            except TransientLLMError:
                row["status"] = "error_permanent"
                reply, tokens = "", 0
            else:
                sent.append((t.ticket_id, system_prompt, user_message, t.text))
                running += tokens
                row.update(tokens_used=tokens, reply=reply)
                row["status"], row["category"] = validate_reply(reply)
            transient_before_recovery += len(retry_log) - before
        rows.append(row)
    return pd.DataFrame(rows), retry_log, sent

def route(df, segments):
    seg = segments.set_index("customer_id")
    df = df.copy()
    df["segment_name"] = df.customer_id.map(seg["segment_name"]).fillna("")
    prem = df.customer_id.map(seg["is_premium"]).fillna(False).astype(bool)   # no row -> not premium
    human = df.status.isin(["skipped_empty", "flagged_long", "flagged_invalid_output", "budget_exhausted", "error_permanent"])
    fraud = ~human & (df.category == "fraud")
    pre = ~human & ~fraud & prem
    df["route"] = "support_queue"; df["priority"] = "NORMAL"
    df.loc[pre, ["route", "priority"]] = ["premium_desk", "HIGH"]
    df.loc[fraud, ["route", "priority"]] = ["security_team", "HIGH"]
    df.loc[human, ["route", "priority"]] = ["human_review", "NORMAL"]
    return df[["ticket_id", "customer_id", "status", "category", "segment_name", "priority", "route", "tokens_used"]]

def summarise(df):
    clf = df[df.status.isin(["classified_json", "classified_keyword"])]
    correct = int((clf.category == clf.true_category).sum())
    total = int(df.tokens_used.sum())
    return {"classified": len(clf), "correct": correct, "accuracy": correct / len(clf) * 100,
            "total_tokens": total, "tokens_per_classified": total / len(clf)}

if __name__ == "__main__":
    tickets = pd.read_csv("data/raw/tickets.csv", keep_default_na=False)       # keep empty texts as ""
    segments = pd.read_csv("outputs/customer_segments.csv")
    rep = []
    def say(s=""):
        print(s); rep.append(s)

    # ---- Task 1: guardrail counts
    n_empty = int((tickets.text.str.strip() == "").sum())
    est = tickets.text.map(est_tokens)
    n_long = int((est > MAX_INPUT_TOKENS).sum())
    say("## Task 1 - input guardrails")
    say(f"tickets = {len(tickets)}; empty = {n_empty} (ref 4); too long (est_tokens > {MAX_INPUT_TOKENS}) = {n_long} (ref 4); "
        f"estimated tokens of the long tickets = {sorted(set(est[est > MAX_INPUT_TOKENS]))} (ref 734)")

    # ---- Task 2: redaction over all 164 tickets
    counts, redacted = {}, []
    for s in tickets.text:
        redacted.append(redact(s, counts))
    left = sum(pii_left(s) for s in redacted)
    say("\n## Task 2 - redaction (order: email, phone, order id)")
    say(f"substitutions: emails = {counts['email']} (ref 55), phones = {counts['phone']} (ref 91), "
        f"order ids = {counts['order id']} (ref 132), total = {sum(counts.values())} (ref 278)")
    say(f"re-applying the three patterns to the redacted texts finds {left} matches (ref 0)")
    assert left == 0

    # ---- Task 3: prompts
    say("\n## Task 3 - prompts")
    say(f"zero-shot ({est_tokens(ZERO_SHOT)} est. tokens):\n{ZERO_SHOT}")
    say(f"\nfew-shot ({est_tokens(FEW_SHOT)} est. tokens):\n{FEW_SHOT}")

    # ---- Tasks 4-6: two full runs
    results, details = {}, {}
    for label, prompt in [("zero-shot", ZERO_SHOT), ("few-shot", FEW_SHOT)]:
        df, rlog, sent = run_pipeline(tickets, prompt)
        results[label] = (df, rlog, sent)
        eligible = len(tickets) - n_empty - n_long
        # guardrail + privacy assertions
        assert len(sent) == eligible == (df.status.isin(["classified_json", "classified_keyword", "flagged_invalid_output"])).sum()
        assert not df[df.status.isin(["skipped_empty", "flagged_long"])].reply.any()
        for tid, system, user, raw in sent:
            assert pii_left(user) == 0 and pii_left(system) == 0, f"PII reached the prompt of {tid}"
            assert user == redact(raw), "user message must be exactly the redacted ticket text"
        # retry assertions
        for r in rlog:
            lo, hi = BASE_DELAY * 2 ** r["retry"] * 0.9, BASE_DELAY * 2 ** r["retry"] * 1.15
            assert lo <= r["wait"] <= hi
        assert not (df.status == "error_permanent").any()
        say(f"\n## Run: {label}")
        say(f"model calls that failed transiently and were recovered by a retry: {len(rlog)} (ref 19); permanent errors: 0")
        say("retry log:"); [say("  " + r["line"]) for r in rlog]
        say(f"waits for retry 0 lie between {BASE_DELAY*0.9:.4f} and {BASE_DELAY*1.15:.4f} s: all {len(rlog)} inside the range")
        say("status counts: " + json.dumps(df.status.value_counts().to_dict()))
        df.to_csv(f"reports/run_details_{label.replace('-', '_')}.csv", index=False)

    # ---- Task 6: comparison
    say("\n## Task 6 - zero-shot versus few-shot")
    summ = {k: summarise(v[0]) for k, v in results.items()}
    cmp_tbl = pd.DataFrame(summ).T
    cmp_tbl["accuracy"] = cmp_tbl["accuracy"].round(1); cmp_tbl["tokens_per_classified"] = cmp_tbl["tokens_per_classified"].round(1)
    say(cmp_tbl.to_markdown(floatfmt=".1f"))
    cmp_tbl.to_csv("outputs/prompt_comparison.csv")
    zs = results["zero-shot"][0]; zs_c = zs[zs.status.isin(["classified_json", "classified_keyword"])]
    say("\nZero-shot confusion table (rows = true category, columns = predicted):")
    say(pd.crosstab(zs_c.true_category, zs_c.category).to_markdown())
    errs = zs_c[zs_c.category != zs_c.true_category].groupby(["true_category", "category"]).size()
    say("zero-shot errors (true -> predicted): " + ", ".join(f"{a}->{b}: {n}" for (a, b), n in errs.items()))

    # ---- Task 7a: budget demo (zero-shot, TOKEN_BUDGET = 6000)
    BUDGET_DEMO = 6000
    bd, _, _ = run_pipeline(tickets, ZERO_SHOT, token_budget=BUDGET_DEMO)
    n_ex = int((bd.status == "budget_exhausted").sum())
    say(f"\n## Task 7a - budget demo (zero-shot, TOKEN_BUDGET = {BUDGET_DEMO})")
    say(f"budget_exhausted tickets = {n_ex}; tokens spent = {int(bd.tokens_used.sum())}; status counts: {json.dumps(bd.status.value_counts().to_dict())}")
    assert n_ex >= 1
    route(bd, segments).to_csv("outputs/triage_budget_demo.csv", index=False)

    # ---- Task 7b: final routed output (few-shot, TOKEN_BUDGET = 100000)
    final, _, _ = run_pipeline(tickets, FEW_SHOT, token_budget=100000)
    out = route(final, segments)
    out.to_csv("outputs/triage_results.csv", index=False)
    say("\n## Task 7b - final outputs/triage_results.csv (few-shot, TOKEN_BUDGET = 100000)")
    say(f"rows = {len(out)} (ref 164)")
    say("status counts: " + json.dumps(out.status.value_counts().to_dict()))
    say("route x priority:"); say(out.groupby(["route", "priority"]).size().to_frame("tickets").to_markdown())
    open("reports/part_c_report.md", "w", encoding="utf-8").write("\n".join(rep) + "\n")
