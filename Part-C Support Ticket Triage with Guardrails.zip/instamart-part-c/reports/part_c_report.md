## Task 1 - input guardrails
tickets = 164; empty = 4 (ref 4); too long (est_tokens > 400) = 4 (ref 4); estimated tokens of the long tickets = [734] (ref 734)

## Task 2 - redaction (order: email, phone, order id)
substitutions: emails = 55 (ref 55), phones = 91 (ref 91), order ids = 132 (ref 132), total = 278 (ref 278)
re-applying the three patterns to the redacted texts finds 0 matches (ref 0)

## Task 3 - prompts
zero-shot (33 est. tokens):
You CLASSIFY customer support tickets into exactly one category: billing, delivery, technical or fraud. Reply with JSON only, in the form {"category": "...", "reason": "..."}.

few-shot (149 est. tokens):
You CLASSIFY customer support tickets into exactly one category: billing, delivery, technical or fraud. Reply with JSON only, in the form {"category": "...", "reason": "..."}.
EXAMPLES:
Ticket: I was charged twice for order [ORDER_ID]. Please refund the extra payment. -> {"category": "billing", "reason": "double charge on an order"}
Ticket: My order [ORDER_ID] has not arrived and the rider is not picking up calls. -> {"category": "delivery", "reason": "order not received"}
Ticket: The app crashes every time I open the cart. -> {"category": "technical", "reason": "app fault"}
Ticket: There is an unauthorized transaction on my card linked to order [ORDER_ID]. I did not place it. -> {"category": "fraud", "reason": "transaction the customer did not make"}

## Run: zero-shot
model calls that failed transiently and were recovered by a retry: 19 (ref 19); permanent errors: 0
retry log:
  RETRY ticket=T0124 retry=0 wait=0.0530s
  RETRY ticket=T0121 retry=0 wait=0.0453s
  RETRY ticket=T0072 retry=0 wait=0.0484s
  RETRY ticket=T0156 retry=0 wait=0.0478s
  RETRY ticket=T0099 retry=0 wait=0.0542s
  RETRY ticket=T0077 retry=0 wait=0.0535s
  RETRY ticket=T0146 retry=0 wait=0.0562s
  RETRY ticket=T0001 retry=0 wait=0.0461s
  RETRY ticket=T0051 retry=0 wait=0.0503s
  RETRY ticket=T0109 retry=0 wait=0.0454s
  RETRY ticket=T0066 retry=0 wait=0.0477s
  RETRY ticket=T0089 retry=0 wait=0.0513s
  RETRY ticket=T0004 retry=0 wait=0.0453s
  RETRY ticket=T0045 retry=0 wait=0.0475s
  RETRY ticket=T0096 retry=0 wait=0.0531s
  RETRY ticket=T0058 retry=0 wait=0.0518s
  RETRY ticket=T0083 retry=0 wait=0.0478s
  RETRY ticket=T0133 retry=0 wait=0.0524s
  RETRY ticket=T0078 retry=0 wait=0.0551s
waits for retry 0 lie between 0.0450 and 0.0575 s: all 19 inside the range
status counts: {"classified_json": 135, "classified_keyword": 12, "flagged_invalid_output": 9, "skipped_empty": 4, "flagged_long": 4}

## Run: few-shot
model calls that failed transiently and were recovered by a retry: 19 (ref 19); permanent errors: 0
retry log:
  RETRY ticket=T0124 retry=0 wait=0.0530s
  RETRY ticket=T0121 retry=0 wait=0.0453s
  RETRY ticket=T0072 retry=0 wait=0.0484s
  RETRY ticket=T0156 retry=0 wait=0.0478s
  RETRY ticket=T0099 retry=0 wait=0.0542s
  RETRY ticket=T0077 retry=0 wait=0.0535s
  RETRY ticket=T0146 retry=0 wait=0.0562s
  RETRY ticket=T0001 retry=0 wait=0.0461s
  RETRY ticket=T0051 retry=0 wait=0.0503s
  RETRY ticket=T0109 retry=0 wait=0.0454s
  RETRY ticket=T0066 retry=0 wait=0.0477s
  RETRY ticket=T0089 retry=0 wait=0.0513s
  RETRY ticket=T0004 retry=0 wait=0.0453s
  RETRY ticket=T0045 retry=0 wait=0.0475s
  RETRY ticket=T0096 retry=0 wait=0.0531s
  RETRY ticket=T0058 retry=0 wait=0.0518s
  RETRY ticket=T0083 retry=0 wait=0.0478s
  RETRY ticket=T0133 retry=0 wait=0.0524s
  RETRY ticket=T0078 retry=0 wait=0.0551s
waits for retry 0 lie between 0.0450 and 0.0575 s: all 19 inside the range
status counts: {"classified_json": 135, "classified_keyword": 12, "flagged_invalid_output": 9, "skipped_empty": 4, "flagged_long": 4}

## Task 6 - zero-shot versus few-shot
|           |   classified |   correct |   accuracy |   total_tokens |   tokens_per_classified |
|:----------|-------------:|----------:|-----------:|---------------:|------------------------:|
| zero-shot |        147.0 |     126.0 |       85.7 |        10134.0 |                    68.9 |
| few-shot  |        147.0 |     147.0 |      100.0 |        28230.0 |                   192.0 |

Zero-shot confusion table (rows = true category, columns = predicted):
| true_category   |   billing |   delivery |   fraud |   technical |
|:----------------|----------:|-----------:|--------:|------------:|
| billing         |        38 |          0 |       0 |           0 |
| delivery        |         0 |         35 |       0 |           0 |
| fraud           |        11 |          0 |      24 |           0 |
| technical       |        10 |          0 |       0 |          29 |
zero-shot errors (true -> predicted): fraud->billing: 11, technical->billing: 10

## Task 7a - budget demo (zero-shot, TOKEN_BUDGET = 6000)
budget_exhausted tickets = 63; tokens spent = 6043; status counts: {"classified_json": 81, "budget_exhausted": 63, "classified_keyword": 8, "skipped_empty": 4, "flagged_invalid_output": 4, "flagged_long": 4}

## Task 7b - final outputs/triage_results.csv (few-shot, TOKEN_BUDGET = 100000)
rows = 164 (ref 164)
status counts: {"classified_json": 135, "classified_keyword": 12, "flagged_invalid_output": 9, "skipped_empty": 4, "flagged_long": 4}
route x priority:
|                             |   tickets |
|:----------------------------|----------:|
| ('human_review', 'NORMAL')  |        17 |
| ('premium_desk', 'HIGH')    |        11 |
| ('security_team', 'HIGH')   |        35 |
| ('support_queue', 'NORMAL') |       101 |
