"""run_part_d.py -- runs every Part D task, writes outputs/ and state/, and generates README.md.
Usage:  python generate_data.py && python run_part_d.py"""
import csv, json, os, shutil
from collections import Counter
import rag, agent, tools

BASE = os.path.dirname(os.path.abspath(__file__))
OUT, STATE = os.path.join(BASE, "outputs"), os.path.join(BASE, "state")
for d in (OUT, STATE):                      # start clean so the run is reproducible
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
RUNS = os.path.join(OUT, "agent_runs.jsonl")


def log_run(res, **extra):
    rec = {"scenario_id": res["scenario_id"], "status": res["status"], "final_answer": res["final_answer"],
           "llm_calls": res["llm_calls"], "tokens_used": res["tokens_used"],
           "steps": [{"tool": s["tool"], "arguments": s["arguments"], "observation": s["observation"]}
                     for s in res["steps"]], **extra}
    with open(RUNS, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")


# ---- Tasks 1-4
chunks = rag.load_chunks(40, 10)
chunk_counts = Counter(c["source"] for c in chunks)
top = [h["source"] for h in rag.retrieve("refund policy late delivery")]
ev10, ev0 = rag.evaluate(40, 10), rag.evaluate(40, 0)

# ---- Tasks 5-6: seven scenarios
scen = list(csv.DictReader(open(os.path.join(BASE, "data", "raw", "agent_scenarios.csv"), newline="")))
rows, all_ok = [], True
for s in scen:
    r = agent.run_agent(s["message"], s["scenario_id"])
    log_run(r)
    exp_status = "FALLBACK_MAX_ITERATIONS" if s["expected_outcome"] == "FALLBACK" else s["expected_outcome"]
    ok = r["status"] == exp_status and abs(r["refund_inr"] - float(s["expected_refund_inr"])) <= 0.01
    all_ok &= ok
    rows.append((s["scenario_id"], r["status"], r["refund_inr"], r["llm_calls"], r["tokens_used"], ok))
calls = {r[0]: r[3] for r in rows}

# ---- Task 7: limit demos on S1
s1_msg = scen[0]["message"]
tok = agent.run_agent(s1_msg, "S1", token_limit=200)
log_run(tok, demo="token_limit=200")
tmo = agent.run_agent(s1_msg, "S1", time_limit_seconds=0)
log_run(tmo, demo="time_limit_seconds=0")

# ---- Task 8: crash and resume on S1
try:
    agent.run_agent(s1_msg, "S1", crash_after_tools=2)
    raise SystemExit("expected a simulated crash")
except agent.SimulatedCrash as e:
    crashed_id = e.run_id
pre = json.load(open(os.path.join(STATE, crashed_id + ".json")))["tools_executed"]
res = agent.resume_agent(crashed_id)
log_run(res, demo="crash_after_2_tools_then_resume", run_id=crashed_id)
resume_ok = (res["tools_executed"] == ["get_order", "search_policy", "calculate_refund", "issue_refund"]
             and res["status"] == "REFUND" and abs(res["refund_inr"] - 128.25) <= 0.01)

# ---- Task 9 text (<= 250 words), uses measured counts
COMPARE = (
    f"My ReAct agent asks the model after every observation. Measured model calls: S1 {calls['S1']}, S2 {calls['S2']}, "
    f"S3 {calls['S3']}, S4 {calls['S4']}, S5 {calls['S5']}, S6 {calls['S6']}; S1 used {rows[0][4]} estimated tokens because every "
    f"call re-sends the growing history including the policy chunks. A plan-and-execute design would call the model once "
    f"for the whole step list (get_order, search_policy, calculate_refund, issue_refund) and once more to write the answer, "
    f"so about 2 calls instead of {calls['S1']} and far fewer tokens on the happy path S1, because the history is not re-sent each step.\n\n"
    f"The price is rigidity. For NOT_FOUND (S6, {calls['S6']} calls in ReAct) a pre-written plan would still try to search "
    f"policy and calculate a refund unless the executor detects the error and replans, which costs an extra model call. "
    f"A cancelled order (S5, {calls['S5']} calls) is worse: get_order succeeds, so nothing signals an error, and a fixed plan "
    f"would carry on to calculate and even issue a refund unless every step is guarded by hand-written checks. ReAct "
    f"simply reads the status and stops.\n\n"
    f"For this refund workflow I would choose ReAct, ideally with a cheap code-level guard for obvious dead ends. Money "
    f"moves at the end, the correct next step depends on what the previous tool returned (status, delivery minutes, "
    f"amount above INR 1000), and the extra 2-3 calls per request cost little compared with an unwarranted refund. "
    f"Plan-and-execute would only win for high-volume, uniform requests where cost matters most.")
assert len(COMPARE.split()) <= 250, len(COMPARE.split())

# ---- README
def tbl(header, body):
    return "\n".join(["| " + " | ".join(header) + " |", "|" + "---|" * len(header)] +
                     ["| " + " | ".join(str(x) for x in r) + " |" for r in body])

def split_note(ev):
    return "\n".join(f"- **{q}** returned: \"{a}\"" for q, _, a in ev["failures"])

readme = f"""# Instamart Customer Intelligence — Part D: Policy RAG Assistant and Refund Agent

Everything is offline: `mock_llm.py` is a deterministic stand-in for the model, and no network call or API key is used.

## How to run
```
python generate_data.py      # data/raw/*.csv and data/policies/*.txt
python run_part_d.py         # runs all Part D tasks, writes outputs/, state/ and this README
```
Files: `rag.py` (tasks 1-4), `tools.py` (task 5), `agent.py` (tasks 6-8), `mock_llm.py`, `build_db.py`.
`data/instamart.db` is the Part A database; if you already have yours with an `orders` table it is used as is,
otherwise `build_db.py` builds a stand-in from `orders.csv` (duplicates removed, bad values set to NULL).

## Part D

### 1. Chunking (40 words, overlap 10)
{len(chunks)} chunks in total: {', '.join(f"{k.replace('_policy.txt','')} {v}" for k, v in sorted(chunk_counts.items(), key=lambda kv: -kv[1]))}. Matches the reference (15: refund 4, delivery 3, escalation 3, payment 3, privacy 2).

### 2. TF-IDF retrieval
`retrieve(query, k=3)` fits `TfidfVectorizer()` on the chunk texts, transforms the query with the same fitted vectorizer and ranks by `cosine_similarity`.
For "refund policy late delivery" the top three sources are {top}.

TF (term frequency) measures how often a word occurs within one chunk, and IDF (inverse document frequency) measures how rare the word is across all chunks, so common words count less. A limitation: TF-IDF matches exact words only, so a question such as "money back for a slow rider" would miss "refund" and "late delivery" even though the meaning is the same.

### 3. Augment and answer
`answer(question)` retrieves three chunks and sends a system message containing POLICY ASSISTANT plus a user message `CONTEXT:\\n[file]\\nchunk...\\nQUESTION:\\n<question>` to `mock_llm.chat`, returning the text and sources.

### 4. Retrieval and grounding evaluation
{tbl(["Setting", "Chunks", "Expected doc in top 3 (of 12)", "Answer contains expected_fact (of 12)", "Fallback \"I could not find\" (of 2)"],
     [["40 words, overlap 10", ev10["chunks"], ev10["doc_hits"], ev10["fact_hits"], ev10["fallbacks"]],
      ["40 words, overlap 0", ev0["chunks"], ev0["doc_hits"], ev0["fact_hits"], ev0["fallbacks"]]])}

With overlap 0, {len(ev0['failures'])} answerable questions break:
{split_note(ev0)}

Why: with no overlap the 40-word cut falls in the middle of a sentence, so the part of the answer after the boundary sits in a different chunk. The model then sees a truncated sentence or only a neighbouring sentence (for example the "45 minutes or less" sentence instead of "more than 45 minutes"), and the expected fact is missing. The 10-word overlap repeats the boundary words in both chunks so the full sentence can be reassembled.

### 5. Tools
`tools.py` defines `get_order`, `search_policy`, `calculate_refund`, `issue_refund`, `escalate_to_human` in `TOOLS_SPEC` (name, one-sentence description, JSON-style parameters) and `TOOL_MAP` (name -> function). `issue_refund` and `escalate_to_human` append a JSON line with timestamp and tool name to `outputs/refund_ledger.jsonl`.

### 6. ReAct loop — seven scenarios
{tbl(["Scenario", "Status", "Refund (INR)", "Model calls", "Tokens used", "Matches expected"],
     [(a, b, f"{c:.2f}", d, e, "yes" if ok else "NO") for a, b, c, d, e, ok in rows])}

S7 uses the default `token_limit=6000` and still completes all six model calls before `FALLBACK_MAX_ITERATIONS`.

### 7. Stopping safely
{tbl(["Demo", "Status", "Model calls", "Tokens used"],
     [["S1 with token_limit=200", tok["status"], tok["llm_calls"], tok["tokens_used"]],
      ["S1 with time_limit_seconds=0", tmo["status"], tmo["llm_calls"], tmo["tokens_used"]]])}

The token-limit run stops right after the model call that pushed the total over 200, without executing the tool that call requested. The timeout run stops at the top of the first iteration, before any model call. Both return the steps completed so far and a human-handoff summary in `final_answer`.

### 8. Crash and resume (S1)
A simulated crash is raised right after the second tool execution (its checkpoint `state/{crashed_id}.json` is already saved); `resume_agent("{crashed_id}")` then continues.
- Executed before the crash: {' -> '.join(pre)}
- Executed across crash and resume, in order: **{' -> '.join(res['tools_executed'])}** ({len(res['tools_executed'])} executions, none repeated)
- Final status: **{res['status']} {res['refund_inr']:.2f}**

### 9. ReAct versus plan-and-execute
{COMPARE}

## Outputs
`outputs/agent_runs.jsonl` (one line per run, including the three demo runs), `outputs/refund_ledger.jsonl` (issued and escalated actions), `state/` (checkpoints).
"""
open(os.path.join(BASE, "README.md"), "w", encoding="utf-8").write(readme)

print("chunks", len(chunks), dict(chunk_counts), "| top3", top)
print("eval10", {k: v for k, v in ev10.items() if k != "failures"})
print("eval0 ", {k: v for k, v in ev0.items() if k != "failures"}, "failing:", len(ev0["failures"]))
for r in rows:
    print(r)
print("token demo", tok["status"], "| timeout demo", tmo["status"], "| resume", res["tools_executed"], res["status"], res["refund_inr"])
print("ALL SCENARIOS OK:", all_ok, "| RESUME OK:", resume_ok, "| compare words:", len(COMPARE.split()))
print("agent_runs lines:", sum(1 for _ in open(RUNS)), "| ledger lines:", sum(1 for _ in open(os.path.join(OUT, "refund_ledger.jsonl"))),
      "| checkpoints:", len(os.listdir(STATE)))
