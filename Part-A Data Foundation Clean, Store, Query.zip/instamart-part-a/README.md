# Instamart Customer Intelligence - Part A: Data Foundation

Audit, clean, store and query the (synthetic, fictional) Instamart quick-commerce exports.
All monetary amounts are in **INR**.

## Reproduce

1. Clone the repository and enter it: `git clone <your-repo-url> && cd <repo>` (work is on branch `main`).
2. Create and activate an isolated virtual environment: `python -m venv .venv`, then `source .venv/bin/activate` (Windows: `.venv\Scripts\activate`).
3. Install the libraries: `pip install -r requirements.txt` (pandas, numpy, tabulate; `requirements.txt` was written with `pip freeze`).
4. Generate the raw data: `python generate_data.py` (writes `data/raw/*.csv` and `data/policies/*.txt`; seed 42, so it is deterministic).
5. Audit the raw tables: `python src/01_audit.py` (writes `reports/audit_report.md`).
6. Clean and store: `python src/02_clean.py` (writes `data/clean/*.csv`, `data/instamart.db`, `reports/cleaning_log.json`).
7. Validate: `python src/03_validate.py` - must print exactly `ALL CHECKPOINTS PASSED`.
8. Run the seven SQL queries: `python src/04_run_sql.py` (reads `sql/queries.sql`, writes `reports/sql_results.md`).
9. pandas cross-check and exploratory analysis: `python src/05_pandas_analysis.py` (writes `reports/pandas_analysis.md`).

Steps 4-9 in one go: `./run_all.sh`.

## Repository layout

```
generate_data.py          supplied data generator (unchanged)
src/01_audit.py           raw-data audit
src/02_clean.py           cleaning + CSV/SQLite storage
src/03_validate.py        checkpoint assertions
src/04_run_sql.py         runs sql/queries.sql with pd.read_sql_query
src/05_pandas_analysis.py pivot_table cross-check + EDA
sql/queries.sql           Q1-Q7
reports/                  generated audit, cleaning log, SQL and pandas results
data/raw, data/clean, data/instamart.db, data/policies
```

## 1. Audit of the raw data

Loaded with `keep_default_na=False, na_values=[""]` so that only truly blank cells count as missing and the
literal strings `N/A` / `error` stay visible as unparseable values (otherwise pandas would silently turn `N/A` into
a missing value and the non-numeric count would be 67 instead of 120). Full shape / dtype / missing-value
profile of every table: `reports/audit_report.md`.

| Audit figure | Found | Reference |
|---|---:|---:|
| raw orders.csv rows | 13,084 | 13,084 |
| exact duplicate rows | 119 | 119 |
| rows with status pending | 656 | 656 |
| distinct order_id | 12,309 | 12,309 |
| order_amount entries not convertible to a number | 120 | 120 |
| negative delivery_minutes | 106 | 106 |
| blank delivery_minutes | 2,541 | 2,541 |
| customers: blank age | 61 | 61 |
| customers: age outside 10-100 | 6 | 6 |
| customers: distinct raw city spellings | 24 | 24 |
| customers: distinct non-blank raw gender spellings | 10 | 10 |
| customers: blank gender | 30 | 30 |

Raw shapes: orders (13,084 x 9), customers (1,200 x 5), products (40 x 4).

## 2. Cleaning rules (with the number of rows / values each one changed)

### customers (1,200 rows)

| Rule | Changed |
|---|---:|
| (a) `city`: strip spaces + title case -> 24 spellings become exactly 6 cities | 476 values |
| (b) `gender`: `m/male` -> male, `f/female` -> female, blank -> unknown (10 spellings -> 3 labels) | 610 female, 560 male, 30 unknown |
| (c) `age` outside 10-100 set to missing | 6 values |
| (c) missing ages (61 blank + 6 invalid = 67) filled with the median age of the customer's city via `groupby("city").transform("median")` | 67 values |
| (d) `signup_date` converted to datetime | 1,200 values |

After cleaning: Pune 227, Delhi 210, Bengaluru 197, Chennai 191, Hyderabad 191, Mumbai 184; 0 missing ages, every age between 18 and 60.
(21 of the filled ages are x.5 because a city median over an even count falls between two integers; the median is kept as computed.)

### orders (13,084 raw rows -> 12,309 rows), applied in this order

| # | Rule | Changed |
|---|---|---:|
| 1 | `order_ts` converted to datetime | 13,084 values |
| 2 | Exact duplicate rows removed | 119 rows removed |
| 3 | For each `order_id` keep only the record with the latest `order_ts` (drops the earlier `pending` record) | 656 rows removed |
| 4 | `order_amount` converted with `pd.to_numeric(errors="coerce")`; unparseable entries filled with `round(price_inr * quantity * (1 - discount_pct/100), 2)` | 112 amounts filled |
| 5a | Negative `delivery_minutes` set to missing | 105 values |
| 5b | Completed orders: missing `delivery_minutes` (blank + negatives) filled with the median of the order's product category among completed orders (`groupby` + `transform`) | 774 values |
| 5c | Cancelled orders: `delivery_minutes` left missing (a cancelled order was never delivered; imputing a time would invent data) | 1,199 left missing |

Why 112 / 105 rather than 120 / 106: the raw counts include rows that rules 2-3 had already removed (duplicates and superseded pending rows).

After cleaning: 12,309 rows (one per `order_id`); 11,110 completed and 1,199 cancelled; no pending rows; 0 missing `order_amount`;
0 missing `delivery_minutes` among completed and 1,199 among cancelled; sum of `order_amount` over completed orders = **INR 2,998,668.80**.

## 3. Storage and validation

* `data/clean/customers.csv`, `orders.csv`, `products.csv`
* `data/instamart.db` (SQLite) with tables `customers`, `products`, `orders`; `order_ts` and `signup_date` are stored as text `YYYY-MM-DD HH:MM:SS` / `YYYY-MM-DD`.
* `src/03_validate.py` asserts 15 reference checkpoints (row counts, status counts, no pending rows, no missing amounts, delivery-minutes rules, revenue total INR 2,998,668.80, six cities, city counts, gender counts, age range) and prints exactly `ALL CHECKPOINTS PASSED`.

## 4. SQL analysis (`sql/queries.sql`, run by `src/04_run_sql.py`)

Only completed orders count as revenue/spend. Every reference result is asserted in the script; full outputs: `reports/sql_results.md`.

| Query | Technique | Result | Reference |
|---|---|---|---|
| Q1 | WHERE (amount > 500) then HAVING (sum > 8000) | 30 customers | 30 |
| Q2 | 3-table join: revenue by city x category | 30 rows; total INR 2,998,668.80; largest Bengaluru / Electronics INR 233,909.45 | same |
| Q3 | scalar subquery: price above average catalogue price | 11 products | 11 |
| Q4 | LEFT JOIN: customers with no completed order | 25 customers | 25 |
| Q5 | two CTEs: total spend above average of totals | 550 customers; average INR 2,552.06 | same |
| Q6 | RANK / DENSE_RANK / ROW_NUMBER over `PARTITION BY city` | top per city below; 8 rows with RANK != ROW_NUMBER | same |
| Q7 | running total `SUM(revenue) OVER (ORDER BY day)` | 183 daily rows; last cumulative INR 2,998,668.80 | same |

Q6 top customer per city: Bengaluru C0082 (INR 12,856.20), Chennai C0930 (INR 10,151.40), Delhi C0291 (INR 13,742.60),
Hyderabad C0743 (INR 12,730.05), Mumbai C0693 (INR 14,766.55), Pune C0426 (INR 10,377.10).

**Why ties make RANK() differ from ROW_NUMBER():** RANK() gives customers with equal spend the same rank and then skips the following ranks, whereas ROW_NUMBER() always counts 1, 2, 3... so after a tie the two numbers diverge for every later row in that city.

## 5. pandas cross-check and exploratory analysis (`src/05_pandas_analysis.py`)

**(a)** `pd.pivot_table(..., margins=True)` grand total = INR 2,998,668.80 = SQL total. Per city (completed orders):

| City | Sum (INR) | Mean (INR) | Count |
|---|---:|---:|---:|
| Bengaluru | 523,643.40 | 276.47 | 1,894 |
| Chennai | 463,629.15 | 272.72 | 1,700 |
| Delhi | 502,829.80 | 243.62 | 2,064 |
| Hyderabad | 528,589.90 | 284.95 | 1,855 |
| Mumbai | 479,058.50 | 297.00 | 1,613 |
| Pune | 500,918.05 | 252.48 | 1,984 |

**(b)** Completed `order_amount`: mean 269.91, median 135.00, skewness 4.61, Q1 64.80, Q3 297.00 (IQR 232.20),
fences -283.50 / 645.30, outliers below the lower fence: 0, above the upper fence: 897.

Correlation matrix (completed orders):

| | order_amount | discount_pct | quantity | delivery_minutes |
|---|---:|---:|---:|---:|
| order_amount | 1.000 | -0.095 | 0.087 | -0.003 |
| discount_pct | -0.095 | 1.000 | -0.000 | -0.010 |
| quantity | 0.087 | -0.000 | 1.000 | -0.013 |
| delivery_minutes | -0.003 | -0.010 | -0.013 | 1.000 |

### The four questions (under 200 words)

**What is the data about?** About 12,300 synthetic quick-commerce orders (April-September 2025) from 1,200 customers in six Indian cities; 11,110 were completed.

**Distributions and statistics?** Order values are strongly right-skewed: mean INR 269.91 against median INR 135.00, skewness 4.61. Most baskets are small (Q1 64.80, Q3 297.00).

**Outliers or anomalies?** 897 orders exceed the upper fence of INR 645.30 and none fall below the lower one. About 71% (635) are Electronics, so these are genuine high-priced purchases, not errors. The raw data's real anomalies (duplicates, negative delivery times, impossible ages) were fixed during cleaning.

**Relationships?** All correlations are very weak. The largest in absolute value is order_amount with discount_pct (-0.095), just ahead of order_amount with quantity (+0.087). Correlation of this size does not establish causation, and it explains under 1% of the variance.
