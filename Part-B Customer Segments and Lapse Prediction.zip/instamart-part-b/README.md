# Instamart Customer Intelligence - Part B: Customer Segments and Lapse Prediction

All monetary amounts are in **INR**. The data is synthetic and fictional.

## Reproduce

Part B consumes the clean tables produced by Part A. The three files it needs are already included in `data/clean/`
(`orders.csv`, `customers.csv`, `products.csv`); to regenerate them from scratch, run Part A first.

1. Clone the repository and enter it (work is on branch `main`).
2. Create and activate an isolated virtual environment: `python -m venv .venv`, then `source .venv/bin/activate` (Windows: `.venv\Scripts\activate`).
3. Install the libraries: `pip install -r requirements.txt` (pandas, numpy, scikit-learn, joblib, tabulate; write your own with `pip freeze` in your venv).
4. RFM, K-means, profile, PCA, segment file: `python src/06_rfm_segments.py`
   (writes `outputs/customer_segments.csv`, `outputs/kmeans_sweep.csv`, `outputs/pca_projection.csv`, `reports/part_b_segments.md`).
5. Lapse model, tuning, balance experiment, persistence, retention list: `python src/07_lapse_model.py`
   (writes `outputs/lapse_model.joblib`, `outputs/retention_list.csv`, `outputs/lapse_features.csv`, `outputs/balance_experiment.csv`, `reports/part_b_lapse_model.md`).
6. Acceptance checks: `python src/08_validate_b.py` - prints `PART B ALL CHECKS PASSED`.

Steps 4-6 in one go: `./run_part_b.sh`. Run step 4 before step 5 (the retention list reads `outputs/customer_segments.csv`).

## Repository layout

```
src/06_rfm_segments.py    RFM, K-means, segments, PCA
src/07_lapse_model.py     lapse label/features, tuning, balance experiment, persistence, retention list
src/08_validate_b.py      acceptance checks
data/clean/               input tables from Part A
outputs/                  deliverables (segments, model, retention list, ...)
reports/                  generated result reports
```

---

## Part B details

Input: `data/clean/orders.csv` and `data/clean/customers.csv` from Part A. Only **completed** orders describe customer behaviour.
All seeds are fixed (`random_state=42`), so every number below is reproducible with the commands above.

## Leakage guarantees (explicit statements)

* **No encoder, scaler or resampler saw test rows.** Scaling and one-hot encoding live inside a scikit-learn `Pipeline`/`ColumnTransformer`, so they are fitted on training rows only (and, inside `GridSearchCV`, only on each fold's training part) and merely applied to the test rows. The over-sampler duplicated rows of the training set only.
* **No data from 2025-09-01 onwards entered the features.** The lapse features use orders with `order_ts < 2025-09-01` only; the script asserts `max(order_ts) < cutoff` on the feature source. The September window is used only to build the label.
* **The segment labels from task 3 were not used as features** (`08_validate_b.py` asserts that no segment column is in the feature table).

## B1. RFM table (snapshot 2025-10-01 00:00:00)

recency = `(snapshot - last_completed_order_ts).dt.days`; frequency = distinct completed orders; monetary = sum of completed `order_amount`.

| Statistic | Found | Reference |
|---|---:|---:|
| customers with a completed order | 1,175 | 1,175 |
| recency median / min / max | 19 / 0 / 180 | 19 / 0 / 180 |
| frequency mean / max | 9.46 / 33 | 9.46 / 33 |
| monetary mean / max (INR) | 2,552.06 / 14,766.55 | 2,552.06 / 14,766.55 |

## B2. K-means (StandardScaler, `KMeans(n_clusters=K, n_init=10, random_state=42)`)

| K | Inertia | Silhouette | Reference inertia | Reference silhouette |
|---:|---:|---:|---:|---:|
| 2 | 1820.8 | 0.465 | 1820.8 | 0.465 |
| 3 | 1268.2 | 0.445 | 1268.2 | 0.445 |
| 4 | 743.1 | 0.526 | 743.1 | 0.526 |
| 5 | 617.4 | 0.480 | 617.4 | 0.481 |
| 6 | 503.2 | 0.482 | 503.2 | 0.482 |
| 7 | 408.5 | 0.416 | 408.5 | 0.416 |
| 8 | 366.5 | 0.412 | 366.5 | 0.412 |

**Reading the elbow.** Inertia falls by 553 from K=2 to 3 and by 525 from K=3 to 4, but only by 126 from K=4 to 5 and by 114, 95 and 42 afterwards, so the curve bends sharply at **K=4**. The silhouette score also peaks at K=4 (0.526, the best of all K from 2 to 8), and four segments are a number the business can act on (see B3).
**Chosen K = 4** (from {3, 4, 5}).

**Why K=8 always has lower inertia than K=2, yet that cannot pick K:** inertia is the within-cluster sum of squared distances, and every extra centroid can only keep it equal or reduce it (with K equal to the number of customers it would be 0), so the lowest inertia always belongs to the largest K. The choice therefore has to come from where the improvement flattens (the elbow), from cluster separation (silhouette) and from whether the segments are usable.

## B3. Segment profile, names and PCA

Cluster numbers are only labels produced by K-means; they carry **no ordering** (segment 3 is not "better" than segment 0). Names below were assigned from the profile, not from the number. **Premium** = the segment with the highest mean monetary value.

| segment_id | Business name | Size | Mean recency (days) | Mean frequency | Mean monetary (INR) | Premium | Recommended action |
|---:|---|---:|---:|---:|---:|:---:|---|
| 0 | Occasional Low-Value Buyers | 436 | 28.86 | 3.77 | 1,057.62 | no | Grow frequency: introductory bundles and category cross-sell nudges. |
| 1 | **Premium Big Spenders** | 138 | 24.12 | 6.77 | 7,129.70 | **yes** | VIP programme: early access to Electronics launches, dedicated support, personal win-back offers. |
| 2 | Loyal Everyday Shoppers | 419 | 8.77 | 19.40 | 3,410.02 | no | Protect the habit: subscriptions, free-delivery thresholds, basket-building rewards. |
| 3 | Dormant / Lapsing | 182 | 109.04 | 2.20 | 685.99 | no | Win-back: time-limited coupon and a "we miss you" message before they are lost. |

All reference values for K=4 are matched (sizes 436 / 138 / 419 / 182; Premium mean monetary about 7,130 and frequency about 6.8; Loyal mean frequency about 19.4 and recency about 8.8).

**PCA (2 components) on the scaled RFM matrix:** `explained_variance_ratio_` = 0.634 and 0.218, total **0.852** (reference 0.634 / 0.218 / 0.852). Two components keep about 85% of the variance of the three standardised columns.

Output: `outputs/customer_segments.csv` with `customer_id, recency, frequency, monetary, segment_id, segment_name, is_premium` (the Premium flag is true for exactly the highest-mean-monetary segment).

## B4. The lapse problem

Cutoff **2025-09-01**. Cohort = customers with at least one completed order before the cutoff. `lapsed = 1` if the customer has **no** completed order dated 2025-09-01 to 2025-09-30, else 0.

Features (all from orders before the cutoff plus the clean customer table): recency (days from cutoff to last completed order), frequency, monetary, average `discount_pct` of completed orders, cancellation rate (cancelled / all orders with a final status), average `delivery_minutes` of completed orders, most frequent product category (ties broken alphabetically), city, age, gender, tenure in days (cutoff minus `signup_date`).

| Item | Found | Reference |
|---|---:|---:|
| cohort | 1,156 | 1,156 |
| lapsed | 443 (38.32%) | 443 (38.32%) |
| train / test (`train_test_split(test_size=0.2, stratify=y, random_state=42)`) | 924 / 232 | 924 / 232 |
| always "not lapsed" on the test set: accuracy / lapsed-class F1 | 61.6% / 0.00 | 61.6% / 0 |

## B5. Preprocessing without leakage

Nominal columns (`city`, `gender`, `favourite_category`) are one-hot encoded with `OneHotEncoder(drop="first")` (k-1 columns per variable, 11 columns), the 8 numeric features are standardised with `StandardScaler`; both are steps of the pipeline and fitted on training rows only.
The learned mean of `frequency` in the fitted scaler is **8.1147**, against **8.0285** for the full cohort. **They differ because the scaler learned its mean from the 924 training rows only, while the full-cohort mean also includes the 232 test rows that the scaler must never see.**
The code asserts that no feature column (raw or encoded) contains a missing value.

## B6. Training, tuning, evaluation (positive class = lapsed)

| Model | Grid | Best parameters | Best CV F1 |
|---|---|---|---:|
| Logistic regression (`max_iter=1000`) | C in {0.01, 0.1, 1, 10, 100}, cv=5, scoring f1 | C = 100 | 0.651 |
| Random forest (`n_estimators=100, random_state=42`) | max_depth in {3, 5, 8} x min_samples_leaf in {5, 10, 20}, cv=5, scoring f1 (45 fits) | max_depth = 8, min_samples_leaf = 10 | 0.681 |

(For logistic regression the CV F1 is 0.645-0.651 for every C from 0.1 to 100, so C=100 versus the reference C=1 is within noise. The random-forest optimum equals the reference.)

Untouched test set (232 customers, 89 truly lapsed). Confusion matrix layout: `[[TN, FP], [FN, TP]]`.

| Model | Confusion matrix | Precision | Recall | F1 |
|---|---|---:|---:|---:|
| Baseline "never lapses" | [[143, 0], [89, 0]] | 0.000 | 0.000 | 0.000 |
| Logistic regression | [[111, 32], [31, 58]] | 0.644 | 0.652 | 0.648 |
| **Random forest (selected)** | [[113, 30], [31, 58]] | 0.659 | 0.652 | **0.655** |

**Choice: random forest.** It has the higher cross-validated F1 (0.681 against 0.651), and on the test set it is slightly better on precision and F1 with identical recall; the choice was made from the cross-validation score and merely confirmed on the test set. Missing a lapsing customer (a false negative) means losing all of that customer's future orders, which for an average customer is worth far more than the cost of a coupon wasted on a loyal customer who was wrongly targeted (a false positive), so recall deserves more weight than precision. At the default 0.5 threshold both tuned models catch only 58 of 89 lapsing customers, so the team should treat the score as a ranking and lower the threshold (or use the balanced model in B7) when the offer is cheap. The selected model's test F1 of 0.655 clears the required 0.55 and is far above the baseline's 0.

## B7. Class-balance experiment

The 354 lapsed training rows were increased to 570 by adding 216 randomly drawn duplicates (with replacement, `random_state=42`) to the unchanged 924 training rows; both classes then have 570 rows. The best logistic regression was refitted on that data and scored on the original test set.

| Metric | Un-balanced LR | Balanced LR | Change |
|---|---:|---:|---:|
| Precision | 0.644 | 0.589 | -0.055 |
| Recall | 0.652 | 0.854 | **+0.202** |
| F1 | 0.648 | 0.697 | +0.049 |

Balanced confusion matrix: [[90, 53], [13, 76]]. **Recall moved most** (from 0.652 to 0.854), while precision did not rise (it fell to 0.589). For the retention team this means over-sampling makes the model flag far more customers: it finds 76 of the 89 lapsing customers instead of 58, but also targets 53 loyal customers by mistake instead of 32. That is a good trade whenever the offer is cheap compared with the revenue of a lost customer, but it is not a more accurate model, only a different operating point.

## B8. Interpretation, persistence and use

**(a) Five most important random-forest features** (`feature_importances_`):

| Feature | Importance | Business reading |
|---|---:|---|
| frequency | 0.280 | How often someone orders is the strongest signal of whether they will still order next month. |
| monetary | 0.271 | Total spend partly repeats frequency but also separates big-ticket Electronics buyers from small-basket buyers. |
| recency | 0.115 | Days since the last order matters, but less than the order history itself. |
| avg_delivery_minutes | 0.061 | Slower average delivery has a small effect on churn. |
| cancellation_rate | 0.052 | The share of cancelled orders is a minor signal. |

**Sign of three logistic-regression coefficients** (standardised features; a positive sign means more likely to lapse):

| Feature | Coefficient | Business reading |
|---|---:|---|
| frequency | -1.698 | Strongly negative: customers who order often rarely lapse, so frequency is the lever to protect. |
| recency | +0.040 | Slightly positive: a longer gap since the last order raises lapse risk, but the effect is small once frequency is known. |
| cancellation_rate | -0.124 | Slightly negative and close to zero: cancellations do not reliably predict lapse in this data, so it should not drive a campaign. |

**(b) Persistence.** The whole selected pipeline (preprocessing and random forest) is saved with `joblib.dump` to `outputs/lapse_model.joblib`; the reloaded model reproduces the original test predictions (and probabilities) exactly.

**(c) Retention list.** Of the 232 test customers, 40 are in the Premium segment; the 10 with the highest predicted lapse probability are in `outputs/retention_list.csv` (`customer_id, lapse_probability, actually_lapsed`), and **1 of those 10 truly lapsed**.
This retention list is illustrative and not a leakage-free evaluation, because the Premium flag comes from the whole-window RFM of task 3, which includes the September window that defines the lapse label.

## Limitations and Next Steps

* **The Premium flag is a post-hoc whole-window label**: it is computed from RFM up to 2025-10-01, which includes September, the very window that defines `lapsed`. Therefore the retention list is illustrative and not a leakage-free evaluation (the low hit rate of 1 in 10 is consistent with that: customers who ordered enough in September to look "Premium" are by construction less likely to be labelled lapsed). The model's own features use only orders before the cutoff.
* Small test set (232 rows, 89 positives): one more or fewer correct prediction moves F1 by about 0.01, so the difference between the two tuned models (0.655 vs 0.648) is not significant.
* All the figures come from synthetic data in which orders are drawn at random over time, so recency carries little information; real data would probably behave differently.
* Frequency and monetary are correlated, so individual logistic-regression coefficients (for instance the small positive one for monetary) must be read together, not separately. K-means on skewed RFM variables is sensitive to a few large customers.
* Random over-sampling duplicates rows and can overfit; the 0.5 threshold was not tuned.
* Next steps: build the Premium/segment flag from data before the cutoff only (a true time-based split), tune the decision threshold against the real cost of an offer and the margin of a retained customer, add features such as order-gap trends, validate with a later month, and monitor the model for drift.
