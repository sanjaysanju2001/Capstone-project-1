"""Part B / Tasks 4-8 - lapse definition, leak-free preprocessing, tuned models, class-balance experiment,
interpretation, persistence and the Premium retention list."""
import os
import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

os.makedirs("outputs", exist_ok=True); os.makedirs("reports", exist_ok=True)
CUTOFF, LABEL_END = pd.Timestamp("2025-09-01"), pd.Timestamp("2025-10-01")
rep = []
def say(s=""):
    print(s); rep.append(s)

orders = pd.read_csv("data/clean/orders.csv", parse_dates=["order_ts"])
cust = pd.read_csv("data/clean/customers.csv", parse_dates=["signup_date"])
prod = pd.read_csv("data/clean/products.csv")
orders = orders.merge(prod[["product_id", "category"]], on="product_id", how="left")

# =====================================================================  Task 4: lapse problem
# ---- FEATURES: only orders strictly before the cutoff ----
pre = orders[orders.order_ts < CUTOFF]
assert pre.order_ts.max() < CUTOFF                                   # leakage guard: nothing from 2025-09-01 on
pre_c = pre[pre.status == "completed"]
gc = pre_c.groupby("customer_id")
feat = pd.DataFrame({
    "recency": (CUTOFF - gc["order_ts"].max()).dt.days,
    "frequency": gc["order_id"].nunique(),
    "monetary": gc["order_amount"].sum().round(2),
    "avg_discount_pct": gc["discount_pct"].mean(),
    "avg_delivery_minutes": gc["delivery_minutes"].mean(),
})
n_all = pre[pre.status.isin(["completed", "cancelled"])].groupby("customer_id")["order_id"].nunique()
n_can = pre[pre.status == "cancelled"].groupby("customer_id")["order_id"].nunique()
feat["cancellation_rate"] = (n_can.reindex(feat.index).fillna(0) / n_all.reindex(feat.index)).round(4)
# favourite category: most completed orders; ties broken alphabetically (deterministic)
cat_cnt = pre_c.groupby(["customer_id", "category"]).size().rename("n").reset_index()
fav = cat_cnt.sort_values(["customer_id", "n", "category"], ascending=[True, False, True]).drop_duplicates("customer_id")
feat["favourite_category"] = fav.set_index("customer_id")["category"]
feat = feat.join(cust.set_index("customer_id")[["city", "age", "gender", "signup_date"]], how="left")
feat["tenure_days"] = (CUTOFF - feat["signup_date"]).dt.days
feat = feat.drop(columns="signup_date")

# ---- LABEL: no completed order in 2025-09-01 .. 2025-09-30 ----
sept = orders[(orders.status == "completed") & (orders.order_ts >= CUTOFF) & (orders.order_ts < LABEL_END)]
active = set(sept.customer_id)
y = pd.Series([0 if c in active else 1 for c in feat.index], index=feat.index, name="lapsed")

NUM = ["recency", "frequency", "monetary", "avg_discount_pct", "cancellation_rate", "avg_delivery_minutes", "age", "tenure_days"]
CAT = ["city", "gender", "favourite_category"]
X = feat[NUM + CAT]
assert X.isna().sum().sum() == 0, "feature matrix must have no missing values"
say("## Task 4 - lapse problem (cutoff 2025-09-01)")
say(f"cohort = {len(X)} (ref 1,156); lapsed = {int(y.sum())} ({y.mean()*100:.2f}%) (ref 443 / 38.32%)")
assert len(X) == 1156 and int(y.sum()) == 443

X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
say(f"train = {len(X_tr)} / test = {len(X_te)} (ref 924 / 232); lapsed in train = {int(y_tr.sum())}, in test = {int(y_te.sum())}")
assert (len(X_tr), len(X_te)) == (924, 232)
pd.concat([X, y], axis=1).reset_index().to_csv("outputs/lapse_features.csv", index=False)

# =====================================================================  Task 5: preprocessing (inside the Pipeline)
def make_pre():
    return ColumnTransformer([("num", StandardScaler(), NUM),
                              ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), CAT)])

def metrics(y_true, y_pred):
    return {"precision": precision_score(y_true, y_pred, pos_label=1, zero_division=0),
            "recall": recall_score(y_true, y_pred, pos_label=1, zero_division=0),
            "f1": f1_score(y_true, y_pred, pos_label=1, zero_division=0)}

say("\n## Task 5 - preprocessing without leakage")
probe = Pipeline([("pre", make_pre())]).fit(X_tr)                    # fitted on TRAINING rows only
scaler = probe.named_steps["pre"].named_transformers_["num"]
mu_scaler = scaler.mean_[NUM.index("frequency")]
say(f"scaler.mean_ for frequency (train only) = {mu_scaler:.4f}; full-cohort mean of frequency = {X['frequency'].mean():.4f}")
say("They differ because the scaler learned its mean from the 924 training rows only, while the full-cohort mean also includes the 232 test rows the scaler must never see.")
Xt_tr, Xt_te = probe.transform(X_tr), probe.transform(X_te)
Xt_tr = Xt_tr.toarray() if hasattr(Xt_tr, "toarray") else Xt_tr
Xt_te = Xt_te.toarray() if hasattr(Xt_te, "toarray") else Xt_te
assert X_tr.isna().sum().sum() == 0 and X_te.isna().sum().sum() == 0
assert not np.isnan(Xt_tr).any() and not np.isnan(Xt_te).any()
feat_names = list(probe.named_steps["pre"].get_feature_names_out())
say(f"no missing value in any feature column (raw or encoded): True; encoded width = {Xt_tr.shape[1]} "
    f"({len(NUM)} numeric + {Xt_tr.shape[1]-len(NUM)} one-hot columns, k-1 per variable)")

# =====================================================================  Task 6: train, tune, evaluate
say("\n## Task 6 - train, tune, evaluate")
base_pred = np.zeros(len(y_te), dtype=int)
base = metrics(y_te, base_pred); base_acc = accuracy_score(y_te, base_pred)
say(f"(a) baseline 'always not lapsed': accuracy = {base_acc*100:.1f}% (ref 61.6%), lapsed-class F1 = {base['f1']:.2f} (ref 0)")
assert round(base_acc * 100, 1) == 61.6 and base["f1"] == 0

lr_gs = GridSearchCV(Pipeline([("pre", make_pre()), ("clf", LogisticRegression(max_iter=1000))]),
                     {"clf__C": [0.01, 0.1, 1, 10, 100]}, cv=5, scoring="f1").fit(X_tr, y_tr)
rf_gs = GridSearchCV(Pipeline([("pre", make_pre()), ("clf", RandomForestClassifier(n_estimators=100, random_state=42))]),
                     {"clf__max_depth": [3, 5, 8], "clf__min_samples_leaf": [5, 10, 20]}, cv=5, scoring="f1").fit(X_tr, y_tr)
say(f"(b) LogisticRegression grid C in {{0.01,0.1,1,10,100}}, cv=5, f1: best {lr_gs.best_params_}, best CV F1 = {lr_gs.best_score_:.4f}")
say(f"(c) RandomForest grid max_depth in {{3,5,8}} x min_samples_leaf in {{5,10,20}}, cv=5, f1 (45 fits): "
    f"best {rf_gs.best_params_}, best CV F1 = {rf_gs.best_score_:.4f}")
cv_tbl = pd.DataFrame(rf_gs.cv_results_)[["param_clf__max_depth", "param_clf__min_samples_leaf", "mean_test_score"]]
say("\nRandom-forest grid (mean CV F1):"); say(cv_tbl.round(4).to_markdown(index=False))
say("\nLogistic-regression grid (mean CV F1):")
say(pd.DataFrame({"C": lr_gs.cv_results_["param_clf__C"], "mean_cv_f1": lr_gs.cv_results_["mean_test_score"]}).round(4).to_markdown(index=False))

say("\n(d) Untouched test set (positive class = lapsed):")
res = {}
for name, gs in [("Logistic regression", lr_gs), ("Random forest", rf_gs)]:
    pred = gs.predict(X_te); m = metrics(y_te, pred); cm = confusion_matrix(y_te, pred)
    res[name] = (m, cm)
    say(f"\n{name}: precision = {m['precision']:.3f}, recall = {m['recall']:.3f}, F1 = {m['f1']:.3f}")
    say(f"confusion matrix [[TN FP],[FN TP]] = {cm.tolist()}")
# model selection from CROSS-VALIDATED F1 (not from the test set), then reported on test
sel_name = "Random forest" if rf_gs.best_score_ >= lr_gs.best_score_ else "Logistic regression"
sel_gs = rf_gs if sel_name == "Random forest" else lr_gs
say(f"\nSelected model (higher cross-validated F1): {sel_name}; test F1 = {res[sel_name][0]['f1']:.3f}")
assert res[sel_name][0]["f1"] >= 0.55

# =====================================================================  Task 7: class-balance experiment
say("\n## Task 7 - class-balance experiment (over-sampling the TRAINING set only)")
n_min, n_maj = int(y_tr.sum()), int((y_tr == 0).sum())
extra = X_tr[y_tr == 1].sample(n=n_maj - n_min, replace=True, random_state=42)
X_bal = pd.concat([X_tr, extra]); y_bal = pd.concat([y_tr, pd.Series(1, index=extra.index)])
say(f"training rows before: {n_maj} not lapsed / {n_min} lapsed; added {len(extra)} duplicated lapsed rows -> {int((y_bal==0).sum())} / {int(y_bal.sum())}")
assert int((y_bal == 0).sum()) == int(y_bal.sum()) == 570
lr_bal = clone(lr_gs.best_estimator_).fit(X_bal, y_bal)
m_un, m_bal = res["Logistic regression"][0], metrics(y_te, lr_bal.predict(X_te))
cmp = pd.DataFrame({"un-balanced LR": m_un, "balanced LR": m_bal}); cmp["change"] = cmp["balanced LR"] - cmp["un-balanced LR"]
say(cmp.round(3).to_markdown(floatfmt=".3f"))
say(f"confusion matrix balanced LR = {confusion_matrix(y_te, lr_bal.predict(X_te)).tolist()}")
cmp.round(4).to_csv("outputs/balance_experiment.csv")

# =====================================================================  Task 8: interpret, persist, use
say("\n## Task 8 - interpret, persist, use")
rf_best = rf_gs.best_estimator_
imp = pd.Series(rf_best.named_steps["clf"].feature_importances_, index=list(rf_best.named_steps["pre"].get_feature_names_out()))
top5 = imp.sort_values(ascending=False).head(5)
say("(a) top 5 random-forest feature_importances_:"); say(top5.round(4).to_frame("importance").to_markdown(floatfmt=".4f"))
coef = pd.Series(lr_gs.best_estimator_.named_steps["clf"].coef_[0],
                 index=list(lr_gs.best_estimator_.named_steps["pre"].get_feature_names_out()))
coef_show = coef[["num__recency", "num__frequency", "num__cancellation_rate", "num__avg_delivery_minutes", "num__monetary"]]
say("logistic-regression coefficients (standardised numeric features; positive = more likely to lapse):")
say(coef_show.round(4).to_frame("coef").to_markdown(floatfmt=".4f"))

joblib.dump(sel_gs.best_estimator_, "outputs/lapse_model.joblib")
re_model = joblib.load("outputs/lapse_model.joblib")
p_orig, p_re = sel_gs.best_estimator_.predict(X_te), re_model.predict(X_te)
same = np.array_equal(p_orig, p_re) and np.allclose(sel_gs.best_estimator_.predict_proba(X_te), re_model.predict_proba(X_te))
say(f"\n(b) saved outputs/lapse_model.joblib ({sel_name}); reloaded model reproduces the original test predictions exactly: {same}")
assert same

seg = pd.read_csv("outputs/customer_segments.csv")
prem_ids = set(seg.loc[seg.is_premium, "customer_id"])
proba = pd.Series(re_model.predict_proba(X_te)[:, 1], index=X_te.index)
prem_test = proba[proba.index.isin(prem_ids)].sort_values(ascending=False)
top = prem_test.head(10)
ret = pd.DataFrame({"customer_id": top.index, "lapse_probability": top.values.round(4),
                    "actually_lapsed": y_te.loc[top.index].values})
ret.to_csv("outputs/retention_list.csv", index=False)
say(f"(c) Premium customers in the test set: {len(prem_test)}; top-{len(ret)} written to outputs/retention_list.csv; "
    f"{int(ret.actually_lapsed.sum())} of {len(ret)} truly lapsed.")
say(ret.to_markdown(index=False, floatfmt=".4f"))
say("This retention list is illustrative and not a leakage-free evaluation: the Premium flag comes from whole-window RFM that includes the September window defining the lapse label.")

open("reports/part_b_lapse_model.md", "w", encoding="utf-8").write("\n".join(rep) + "\n")
