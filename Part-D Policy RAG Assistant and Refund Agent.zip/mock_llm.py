"""mock_llm.py -- deterministic offline stand-in for a chat model. No network, no API key.

chat(messages, tools=None) -> {"content": str|None,
                               "tool_calls": [{"id","name","arguments"}],
                               "usage": {"prompt_tokens","completion_tokens","total_tokens"}}

Two behaviours, chosen by the system message:
  * "POLICY ASSISTANT": extractive QA over the CONTEXT block (best-matching sentence, or the
    fallback "I could not find ...").
  * "AGENT": a scripted ReAct policy that decides the next tool call from the message history.
"""
import json, re

STOP = set("""a an the of to in on at is are was were be been it its this that these those for from by with and or
not no do does did can could will would should may might must have has had i my me we you your our they their
what which who whom whose when where why how many much any all there then than so as if into over under""".split())
FALLBACK = "I could not find the answer to that in the policy documents."


def _tokens(text):
    return len(re.findall(r"\w+|[^\w\s]", text))


def _usage(messages, content, tool_calls):
    prompt = sum(_tokens(m.get("content") or "") + _tokens(json.dumps(m.get("tool_calls") or ""))
                 for m in messages)
    comp = _tokens(content or "") + (_tokens(json.dumps(tool_calls)) if tool_calls else 0)
    return {"prompt_tokens": prompt, "completion_tokens": comp, "total_tokens": prompt + comp}


def _stem(w):
    for suf in ("ing", "ed", "es", "s", "y"):
        if w.endswith(suf) and len(w) - len(suf) >= 4:
            return w[:-len(suf)]
    return w


def _content_words(text):
    return {_stem(w) for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOP}


# ---------------- policy assistant ----------------
def _policy_answer(user):
    m = re.search(r"CONTEXT:\n(.*)\nQUESTION:\n(.*)$", user, re.S)
    if not m:
        return FALLBACK
    context, question = m.group(1), m.group(2).strip()
    q = _content_words(question)
    # parse "[file.txt]\n<chunk>" blocks, then stitch chunks of one file whose edges overlap
    blocks, src = {}, None
    for ln in context.split("\n"):
        h = re.fullmatch(r"\[([\w.]+)\]", ln.strip())
        if h:
            src = h.group(1)
        elif src and ln.strip():
            blocks.setdefault(src, []).append(ln.strip().split())
    texts = []
    for parts in blocks.values():
        merged = True
        while merged and len(parts) > 1:
            merged = False
            for i in range(len(parts)):
                for j in range(len(parts)):
                    if i == j:
                        continue
                    a, b = parts[i], parts[j]
                    k = next((k for k in range(min(len(a), len(b)), 4, -1) if a[-k:] == b[:k]), 0)
                    if k:
                        parts[i] = a + b[k:]
                        del parts[j]
                        merged = True
                        break
                if merged:
                    break
        texts += [" ".join(p) for p in parts]
    sentences = []
    for t in texts:
        sentences += [s.strip() for s in re.split(r"(?<=\.)\s+", t) if s.strip()]
    best, best_key = None, (0, 0)
    for s in sentences:
        score = len(q & _content_words(s))
        key = (score, len(s))
        if key > best_key:
            best, best_key = s, key
    if best is None or best_key[0] < 2:
        return FALLBACK
    return best


# ---------------- scripted ReAct agent ----------------
def _agent_next(messages):
    user = next(m["content"] for m in messages if m["role"] == "user")
    tool_msgs = [m for m in messages if m["role"] == "tool"]
    called = [m["name"] for m in tool_msgs]
    res = {m["name"]: json.loads(m["content"]) for m in tool_msgs}
    oid = re.search(r"ORD-\d+", user)
    n_calls = sum(1 for m in messages if m["role"] == "assistant")

    def call(name, args):
        return None, [{"id": f"call_{n_calls + 1}", "name": name, "arguments": args}]

    if not oid:
        return "NOT_FOUND: no order id was given in the request. Handing over to a human agent.", []
    oid = oid.group(0)
    if not called:
        return call("get_order", {"order_id": oid})
    order = res["get_order"]
    if "error" in order:
        return f"NOT_FOUND: order {oid} does not exist, no refund can be made.", []
    if "[LOOP]" in user:          # simulated agent that never reaches a decision
        return call("search_policy", {"query": "refund policy late delivery"})
    if "search_policy" not in called:
        return call("search_policy", {"query": "refund policy late delivery completed cancelled order"})
    if order["status"] != "completed":
        return f"DENIED: order {oid} has status {order['status']}; only completed orders can be refunded.", []
    if "calculate_refund" not in called:
        return call("calculate_refund", {"order_amount": order["order_amount"],
                                         "delivery_minutes": order["delivery_minutes"]})
    amt = res["calculate_refund"]["refund_inr"]
    if amt <= 0:
        return f"DENIED: order {oid} was delivered in {order['delivery_minutes']} minutes, within 45, so no refund is due.", []
    if "issue_refund" in res:
        return f"REFUND: INR {res['issue_refund']['refund_inr']:.2f} refunded for order {oid}.", []
    if "escalate_to_human" in res:
        return f"ESCALATE: INR {res['escalate_to_human']['refund_inr']:.2f} for order {oid} sent to a human support lead for approval.", []
    if amt > 1000:
        return call("escalate_to_human", {"order_id": oid, "refund_inr": amt})
    return call("issue_refund", {"order_id": oid, "refund_inr": amt})


def chat(messages, tools=None, temperature=0):
    system = next((m["content"] for m in messages if m["role"] == "system"), "")
    user = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")
    if "POLICY ASSISTANT" in system:
        content, tool_calls = _policy_answer(user), []
    elif "AGENT" in system:
        content, tool_calls = _agent_next(messages)
    else:
        content, tool_calls = "I could not find a role for this request.", []
    return {"content": content, "tool_calls": tool_calls, "usage": _usage(messages, content, tool_calls)}
