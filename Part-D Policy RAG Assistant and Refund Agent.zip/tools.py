"""tools.py -- Part D task 5: the five agent tools, TOOLS_SPEC and TOOL_MAP."""
import json, os, sqlite3
from datetime import datetime, timezone
import rag
import build_db

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "data", "instamart.db")
LEDGER = os.path.join(BASE, "outputs", "refund_ledger.jsonl")
os.makedirs(os.path.dirname(LEDGER), exist_ok=True)


def get_order(order_id):
    build_db.build()                      # no-op if data/instamart.db already exists
    con = sqlite3.connect(DB_PATH)
    try:
        row = con.execute("SELECT order_id, status, order_amount, delivery_minutes FROM orders WHERE order_id = ?",
                          (order_id,)).fetchone()
    finally:
        con.close()
    if row is None:
        return {"error": "order not found"}
    return {"order_id": row[0], "status": row[1], "order_amount": row[2], "delivery_minutes": row[3]}


def search_policy(query):
    return {"results": rag.retrieve(query, 3)}


def calculate_refund(order_amount, delivery_minutes):
    """Rules: more than 45 minutes -> 100% of order_amount, otherwise 0. (Only completed orders reach here.)"""
    if order_amount is None or delivery_minutes is None:
        return {"refund_inr": 0.0}
    return {"refund_inr": round(float(order_amount), 2) if delivery_minutes > 45 else 0.0}


def _ledger(tool, order_id, refund_inr):
    rec = {"timestamp": datetime.now(timezone.utc).isoformat(), "tool": tool,
           "order_id": order_id, "refund_inr": refund_inr}
    with open(LEDGER, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec) + "\n")
    return {"refund_inr": refund_inr}


def issue_refund(order_id, refund_inr):
    return _ledger("issue_refund", order_id, refund_inr)


def escalate_to_human(order_id, refund_inr):
    return _ledger("escalate_to_human", order_id, refund_inr)


def _spec(name, desc, props, required):
    return {"name": name, "description": desc,
            "parameters": {"type": "object", "properties": props, "required": required}}


TOOLS_SPEC = [
    _spec("get_order", "Look up an order by id and return its status, order amount and delivery minutes.",
          {"order_id": {"type": "string", "description": "Order id such as ORD-100048"}}, ["order_id"]),
    _spec("search_policy", "Search the company policy documents and return the three most relevant chunks.",
          {"query": {"type": "string", "description": "Free-text search query"}}, ["query"]),
    _spec("calculate_refund", "Compute the refund in INR from the order amount and delivery minutes using the refund rules.",
          {"order_amount": {"type": "number"}, "delivery_minutes": {"type": "integer"}},
          ["order_amount", "delivery_minutes"]),
    _spec("issue_refund", "Issue an automatic refund (up to INR 1000) and record it in the refund ledger.",
          {"order_id": {"type": "string"}, "refund_inr": {"type": "number"}}, ["order_id", "refund_inr"]),
    _spec("escalate_to_human", "Send a refund above INR 1000 to a human support lead and record it in the ledger.",
          {"order_id": {"type": "string"}, "refund_inr": {"type": "number"}}, ["order_id", "refund_inr"]),
]

TOOL_MAP = {"get_order": get_order, "search_policy": search_policy, "calculate_refund": calculate_refund,
            "issue_refund": issue_refund, "escalate_to_human": escalate_to_human}
