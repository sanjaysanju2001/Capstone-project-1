"""Part B / Tasks 1-3 - RFM table, K-means (K=2..8), segment profile + names, PCA, outputs/customer_segments.csv."""
import json, os
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

os.makedirs("outputs", exist_ok=True); os.makedirs("reports", exist_ok=True)
SNAPSHOT = pd.Timestamp("2025-10-01 00:00:00")
rep = []
def say(s=""):
    print(s); rep.append(s)

orders = pd.read_csv("data/clean/orders.csv", parse_dates=["order_ts"])
comp = orders[orders.status == "completed"]

# ---------------- Task 1: RFM ----------------
g = comp.groupby("customer_id")
rfm = pd.DataFrame({"last_ts": g["order_ts"].max(),
                    "frequency": g["order_id"].nunique(),
                    "monetary": g["order_amount"].sum().round(2)})
rfm["recency"] = (SNAPSHOT - rfm["last_ts"]).dt.days
rfm = rfm.drop(columns="last_ts").reset_index()[["customer_id", "recency", "frequency", "monetary"]]
say("## Task 1 - RFM table (snapshot 2025-10-01)")
say(f"customers = {len(rfm)} (ref 1,175)")
say(f"recency  median={rfm.recency.median():.0f} (19)  min={rfm.recency.min()} (0)  max={rfm.recency.max()} (180)")
say(f"frequency mean={rfm.frequency.mean():.2f} (9.46)  max={rfm.frequency.max()} (33)")
say(f"monetary mean={rfm.monetary.mean():,.2f} (2,552.06)  max={rfm.monetary.max():,.2f} (14,766.55)")
assert len(rfm) == 1175 and rfm.recency.median() == 19 and rfm.recency.max() == 180
assert round(rfm.frequency.mean(), 2) == 9.46 and rfm.frequency.max() == 33
assert round(rfm.monetary.mean(), 2) == 2552.06 and rfm.monetary.max() == 14766.55

# ---------------- Task 2: K-means sweep ----------------
X = StandardScaler().fit_transform(rfm[["recency", "frequency", "monetary"]])
ref = {2: (1820.8, .465), 3: (1268.2, .445), 4: (743.1, .526), 5: (617.4, .481),
       6: (503.2, .482), 7: (408.5, .416), 8: (366.5, .412)}
rows = []
for k in range(2, 9):
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    sil = silhouette_score(X, km.labels_)
    rows.append({"K": k, "inertia": round(km.inertia_, 1), "silhouette": round(sil, 3),
                 "ref_inertia": ref[k][0], "ref_silhouette": ref[k][1]})
    assert abs(km.inertia_ / ref[k][0] - 1) <= .05 and abs(sil - ref[k][1]) <= .05, f"K={k} outside tolerance"
sweep = pd.DataFrame(rows)
sweep["inertia_drop_vs_prev_K"] = sweep["inertia"].diff().round(1)
say("\n## Task 2 - K-means sweep (scaled RFM, n_init=10, random_state=42)")
say(sweep.to_markdown(index=False, floatfmt=".3f"))

K = 4          # chosen from {3,4,5}; justification in README
say(f"\nChosen K = {K}")

# ---------------- Task 3: profile, names, PCA ----------------
km = KMeans(n_clusters=K, n_init=10, random_state=42).fit(X)
rfm["segment_id"] = km.labels_
prof = rfm.groupby("segment_id").agg(size=("customer_id", "count"), mean_recency=("recency", "mean"),
                                     mean_frequency=("frequency", "mean"), mean_monetary=("monetary", "mean")).round(2)
say("\n## Task 3a - segment profile (cluster numbers are arbitrary labels with no ordering)")
say(prof.to_markdown(floatfmt=",.2f"))

# data-driven naming (never by cluster number): rules read off the profile
premium_id = prof["mean_monetary"].idxmax()
lapsing_id = prof["mean_recency"].idxmax()
rest = [i for i in prof.index if i not in (premium_id, lapsing_id)]
loyal_id = prof.loc[rest, "mean_frequency"].idxmax()
casual_id = [i for i in rest if i != loyal_id][0]
NAMES = {premium_id: ("Premium Big Spenders",
                      "VIP programme: early access to Electronics launches, a dedicated support line and personal win-back offers."),
         loyal_id: ("Loyal Everyday Shoppers",
                    "Protect the habit: subscriptions, free-delivery thresholds and small basket-building rewards."),
         lapsing_id: ("Dormant / Lapsing",
                      "Win-back: time-limited coupon and a 'we miss you' message before they are lost."),
         casual_id: ("Occasional Low-Value Buyers",
                     "Grow frequency: introductory bundles and category cross-sell nudges.")}
rfm["segment_name"] = rfm["segment_id"].map(lambda s: NAMES[s][0])
rfm["is_premium"] = rfm["segment_id"] == premium_id
prof["segment_name"] = [NAMES[i][0] for i in prof.index]
prof["recommended_action"] = [NAMES[i][1] for i in prof.index]
prof["is_premium"] = prof.index == premium_id
say("\n## Task 3b - names and recommended actions")
say(prof[["segment_name", "size", "mean_recency", "mean_frequency", "mean_monetary", "is_premium", "recommended_action"]]
    .to_markdown(floatfmt=",.2f"))

pca = PCA(n_components=2).fit(X)
evr = pca.explained_variance_ratio_
say(f"\n## Task 3c - PCA explained_variance_ratio_ = {evr[0]:.3f}, {evr[1]:.3f}; total = {evr.sum():.3f} (ref 0.634 / 0.218 / 0.852)")
assert abs(evr[0] - .634) <= .02 and abs(evr[1] - .218) <= .02 and abs(evr.sum() - .852) <= .02
pts = pca.transform(X)
pd.DataFrame({"customer_id": rfm.customer_id, "pc1": pts[:, 0].round(4), "pc2": pts[:, 1].round(4),
              "segment_name": rfm.segment_name}).to_csv("outputs/pca_projection.csv", index=False)

# sanity vs reference for K=4
sizes = sorted(prof["size"].tolist()); say(f"sizes sorted = {sizes} (ref about 138/182/419/436)")
p = prof.loc[premium_id]; l = prof.loc[loyal_id]
say(f"premium: n={int(p['size'])} mean_monetary={p.mean_monetary:,.0f} (~7,130) mean_frequency={p.mean_frequency:.1f} (~6.8)")
say(f"loyal  : n={int(l['size'])} mean_frequency={l.mean_frequency:.1f} (~19.4) mean_recency={l.mean_recency:.1f} (~8.8)")

out = rfm[["customer_id", "recency", "frequency", "monetary", "segment_id", "segment_name", "is_premium"]]
out.to_csv("outputs/customer_segments.csv", index=False)
assert out.loc[out.is_premium, "segment_id"].nunique() == 1 and out.is_premium.sum() == int(p["size"])
sweep.to_csv("outputs/kmeans_sweep.csv", index=False)
open("reports/part_b_segments.md", "w", encoding="utf-8").write("\n".join(rep) + "\n")
