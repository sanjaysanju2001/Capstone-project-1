"""build_db.py -- stand-in for the Part A database (data/instamart.db).

If you already have your own Part A data/instamart.db with an `orders` table, this script
does nothing. Otherwise it builds one from data/raw/orders.csv with the usual cleaning:
drop exact duplicates, keep the non-pending record per order, unparseable amounts and
impossible delivery times become NULL.
"""
import csv, os, sqlite3

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "data", "instamart.db")


def build(force=False):
    if os.path.exists(DB) and not force:
        return DB
    if os.path.exists(DB):
        os.remove(DB)
    best = {}
    with open(os.path.join(BASE, "data", "raw", "orders.csv"), newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            cur = best.get(r["order_id"])
            if cur is None or (cur["status"] == "pending" and r["status"] != "pending"):
                best[r["order_id"]] = r

    def num(x):
        try:
            return float(x)
        except ValueError:
            return None

    con = sqlite3.connect(DB)
    con.execute("""CREATE TABLE orders (order_id TEXT PRIMARY KEY, customer_id TEXT, product_id TEXT,
                   quantity INTEGER, order_ts TEXT, status TEXT, discount_pct INTEGER,
                   order_amount REAL, delivery_minutes INTEGER)""")
    rows = []
    for r in best.values():
        d = num(r["delivery_minutes"])
        d = int(d) if d is not None and 0 < d <= 240 else None
        rows.append((r["order_id"], r["customer_id"], r["product_id"], int(r["quantity"]), r["order_ts"],
                     r["status"], int(r["discount_pct"]), num(r["order_amount"]), d))
    con.executemany("INSERT INTO orders VALUES (?,?,?,?,?,?,?,?,?)", rows)
    con.commit()
    con.close()
    return DB


if __name__ == "__main__":
    print("built", build(force=True))
