## orders.csv  shape=(13084, 9)
|                  | dtype   |   missing |   missing_pct |
|:-----------------|:--------|----------:|--------------:|
| order_id         | str     |         0 |          0    |
| customer_id      | str     |         0 |          0    |
| product_id       | str     |         0 |          0    |
| quantity         | int64   |         0 |          0    |
| order_ts         | str     |         0 |          0    |
| status           | str     |         0 |          0    |
| discount_pct     | int64   |         0 |          0    |
| order_amount     | str     |         0 |          0    |
| delivery_minutes | float64 |      2541 |         19.42 |

## customers.csv  shape=(1200, 5)
|             | dtype   |   missing |   missing_pct |
|:------------|:--------|----------:|--------------:|
| customer_id | str     |         0 |          0    |
| city        | str     |         0 |          0    |
| signup_date | str     |         0 |          0    |
| age         | float64 |        61 |          5.08 |
| gender      | str     |        30 |          2.5  |

## products.csv  shape=(40, 4)
|              | dtype   |   missing |   missing_pct |
|:-------------|:--------|----------:|--------------:|
| product_id   | str     |         0 |             0 |
| product_name | str     |         0 |             0 |
| category     | str     |         0 |             0 |
| price_inr    | int64   |         0 |             0 |

## Audit figures
| audit figure                                       |   found |   reference | match   |
|:---------------------------------------------------|--------:|------------:|:--------|
| raw orders.csv rows                                |   13084 |       13084 | True    |
| exact duplicate rows                               |     119 |         119 | True    |
| rows with status pending                           |     656 |         656 | True    |
| distinct order_id                                  |   12309 |       12309 | True    |
| non-numeric order_amount                           |     120 |         120 | True    |
| negative delivery_minutes                          |     106 |         106 | True    |
| blank delivery_minutes                             |    2541 |        2541 | True    |
| customers: blank age                               |      61 |          61 | True    |
| customers: age outside 10-100                      |       6 |           6 | True    |
| customers: distinct raw city spellings             |      24 |          24 | True    |
| customers: distinct non-blank raw gender spellings |      10 |          10 | True    |
| customers: blank gender                            |      30 |          30 | True    |
