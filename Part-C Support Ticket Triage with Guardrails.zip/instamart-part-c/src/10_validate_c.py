"""Part C acceptance checks on the written output files. Prints exactly PART C ALL CHECKS PASSED on success."""
import pandas as pd

COLS = ["ticket_id", "customer_id", "status", "category", "segment_name", "priority", "route", "tokens_used"]
tickets = pd.read_csv("data/raw/tickets.csv", keep_default_na=False)
seg = pd.read_csv("outputs/customer_segments.csv").set_index("customer_id")
res = pd.read_csv("outputs/triage_results.csv", keep_default_na=False)
demo = pd.read_csv("outputs/triage_budget_demo.csv", keep_default_na=False)

for name, df in [("triage_results", res), ("triage_budget_demo", demo)]:
    assert list(df.columns) == COLS, name
    assert len(df) == 164 and df.ticket_id.tolist() == tickets.ticket_id.tolist(), "164 rows in file order"

# no model call for empty / long tickets: they carry zero tokens and a skip/flag status
assert (res[res.status.isin(["skipped_empty", "flagged_long"])].tokens_used == 0).all()
assert (res.status == "skipped_empty").sum() == 4 and (res.status == "flagged_long").sum() == 4

# routing recomputed independently from the stated rules
def expected(r):
    if r.status in ("skipped_empty", "flagged_long", "flagged_invalid_output", "budget_exhausted", "error_permanent"):
        return "human_review", "NORMAL"
    if r.category == "fraud":
        return "security_team", "HIGH"
    prem = bool(seg.is_premium.get(r.customer_id, False))            # no segment row -> not premium
    return ("premium_desk", "HIGH") if prem else ("support_queue", "NORMAL")
for name, df in [("results", res), ("demo", demo)]:
    for r in df.itertuples():
        assert (r.route, r.priority) == expected(r), (name, r.ticket_id)
        has_cat = r.status in ("classified_json", "classified_keyword")
        assert (r.category != "") == has_cat, "category only for validated answers"
        assert (r.segment_name != "") == (r.customer_id in seg.index), "segment_name blank only without a segment row"

# budget demo: the budget stopped the run
n_ex = (demo.status == "budget_exhausted").sum()
assert n_ex >= 1
assert (demo[demo.status == "budget_exhausted"].route == "human_review").all()
assert (demo[demo.status == "budget_exhausted"].tokens_used == 0).all()

# nothing unvalidated is auto-routed
auto = res[~res.route.eq("human_review")]
assert auto.status.isin(["classified_json", "classified_keyword"]).all()
assert res.status.value_counts().to_dict() == {"classified_json": 135, "classified_keyword": 12,
                                               "flagged_invalid_output": 9, "skipped_empty": 4, "flagged_long": 4}
print("PART C ALL CHECKS PASSED")
